return {
	name = "dns.cfiec.net",
	label = _("CFIEC Public DNS (IPv6 Only)"),
	resolver_url = "https://dns.cfiec.net/dns-query",
	bootstrap_dns = "240C::6666,240C::6644"
}
