


#perl -e 'use strict; print "ok"'
#opkg install --force-checksum perlbase-sys


#opkg install --force-checksum perl-device-serialport #@SerialPort.pm



#opkg install --force-checksum perl-www #@UserAgent.pm ?YES

#>Can't locate Try/Tiny.pm in @INC (you may need to install the Try::Tiny module) (@INC contains: /usr/lib/perl5/5.28) at /usr/lib/perl5/5.28/LWP/Protocol.pm line 11.
#NOPE opkg install --force-checksum perlbase-http-tiny
#NOPE opkg install --force-checksum perlbase-autodie




#sigtrap
#ops
#open
#o
#cwd already



#opkg install --force-checksum $(opkg list | grep '^perl' | grep -v harness | cut -d' ' -f1)








#opkg install --force-checksum perl-lwp-mediatypes
#NOPE#######? opkg install --force-checksum perlbase-user
#Can't locate LWP/UserAgent.pm in @INC (you may need to install the LWP::UserAgent module) (@INC contains: /usr/lib/perl5/5.28) at ./temps.pl line 3.
#BEGIN failed--compilation aborted at ./temps.pl line 3.
















