return {
	name = "freedns.controld.com-p1",
	label = _("ControlD (Block Malware)"),
	resolver_url = "https://freedns.controld.com/p1",
	bootstrap_dns = "76.76.2.1,2606:1a40::1",
	help_link = "https://kb.controld.com/tutorials",
	help_link_text = "ControlD.com"
}
