return {
	name = "doh.dnslify.com",
	label = _("DNSlify DNS"),
	resolver_url = "https://doh.dnslify.com/dns-query",
	bootstrap_dns = "185.235.81.1,185.235.81.2,2a0d:4d00:81::1,2a0d:4d00:81::2",
	help_link = "https://www.dnslify.com/services/doh/",
	help_link_text = "DNSlify.com"
}
