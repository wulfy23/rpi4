#/bin/sysinfo.sh -w 65


if [ -f /root/wrt.ini  ]; then
    . /root/wrt.ini
fi

if [ ! -z "$NOBANNERSYSINFO"  ] || [ ! -z "$NOBANNERMOD"  ]; then
    :
else
    /bin/sysinfo.sh -w 65
fi









