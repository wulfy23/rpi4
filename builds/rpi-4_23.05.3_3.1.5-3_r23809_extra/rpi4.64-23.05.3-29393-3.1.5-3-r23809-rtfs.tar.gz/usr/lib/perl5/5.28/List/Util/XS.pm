package List::Util::XS;
use strict;
use warnings;
use List::Util;

our $VERSION = "1.50";       # FIXUP
$VERSION = eval $VERSION;    # FIXUP

1;
__END__

