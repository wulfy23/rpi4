#!/bin/sh
	sed -i "s|update_dnsmasq_config|dnsmasq_config_update|" "/etc/config/https-dns-proxy"
	sed -i "s|wan6_trigger|procd_trigger_wan6|" "/etc/config/https-dns-proxy"
