return{
	name = "doh.idnet.net",
	label = _("IDNet.net - UK"),
	resolver_url = "https://doh.idnet.net/dns-query",
	bootstrap_dns = "212.69.36.23,212.69.40.23"
}
