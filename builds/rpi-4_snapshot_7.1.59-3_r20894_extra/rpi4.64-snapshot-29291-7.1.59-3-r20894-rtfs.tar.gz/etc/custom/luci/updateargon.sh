




wget --no-check-certificate https://github.com/jerrykuku/luci-theme-argon/releases/download/v2.2.4/luci-theme-argon_2.2.4-20200821_all.ipk


##########Update log 2020.08.21 v2.2.4
#【v2.2.4】Fix the problem that the login background cannot be displayed on some phones.
#【v2.2.4】Remove the dependency of luasocket.
#################################################################
#【v2.2.3】Fix Firmware flash page display error in dark mode.
#【v2.2.3】Update font icon, add a default icon of undefined menu.
##################
#【v2.2.2】Add custom login background,put your image (allow png jpg gif) or MP4 video into /www/luci-static/argon/background, random change.
#【v2.2.2】Add force dark mode, login ssh and type "touch /etc/dark" to open dark mode.
#【v2.2.2】Add a volume mute button for video background, default is muted.
#【v2.2.2】fix login page when keyboard show the bottom text overlay the button on mobile.
#【v2.2.2】fix select color in dark mode,and add a style for scrollbar.
#【v2.2.2】jquery update to v3.5.1.
#【v2.2.2】change request bing api method form wget to luasocket (DEPENDS).
#【v2.2.1】Add blur effect for login form.
#【v2.2.1】New login theme, Request background imge from bing.com, Auto change everyday.
####################





#	if (bgcount == 0 ) then
#		local http = require "luci.sys"
#		local json = require "luci.jsonc"
#		local bg_url = media .. "/img/bg1.jpg"
#		local bing = http.httpget("http://www.bing.com/HPImageArchive.aspx?format=js&idx=0&n=1&mkt=en-US")
#		if (bing and bing ~= '') then
#			local bingjson  = json.parse(bing)
#			bg_url = "https://www.bing.com" .. bingjson.images[1].url
#		end
#	%>
#		style="background-image:url(<%=bg_url%>)"
#	<% elseif  (bgcount > 0 and currentBg["type"] ~= "mp4") then %>
#		style="background-image:url(<%=currentBg.url%>)"
#	<% end  %>









