#!/bin/sh
ecmd="echo "; i=$(basename $0)

if [ -x /etc/custom/custfunc.sh ]; then
	. /etc/custom/custfunc.sh
	ecmd="echm ${i} "
fi









#$ecmd "board MAC private SAMPLE: $1 (firstboot|startup|shutdown|upgrade)" #sleep 5





case "$1" in







	firstboot)

		test -f /root/.firstboot.$i && exit 0 ###############################################
		: #$ecmd "$0 $1"
        	

		$ecmd "second test board disabling odhcpd and dnsmasq"
		/etc/init.d/dnsmasq disable 2>/dev/null
		/etc/init.d/dnsmasq stop 2>/dev/null
		/etc/init.d/odhcpd disable 2>/dev/null
		/etc/init.d/odhcpd stop 2>/dev/null


		touch /root/.firstboot.$i				#############################################

	;; #upgraded) :; ;;



	startup)
		:
		#$ecmd "$0 $1"
    ;; #touch /root/.startup.$i






	everyboot)
		:
		#$ecmd "$0 $1"
	;;




    startuponce) #note: not fully functional -> wip

		test -f /root/.startup.once.$i && exit 0
		
		:
		#$ecmd "$0 $1"
        
		touch /root/.startup.once.$i

	;;



    

	shutdown)
		:
		#$ecmd "$0 $1"    
	;;


	upgrade)
		:
		#$ecmd "$0 $1"    
	;;



	online)
		:
		#$ecmd "$0 $1"    
	;;


esac







exit 0







