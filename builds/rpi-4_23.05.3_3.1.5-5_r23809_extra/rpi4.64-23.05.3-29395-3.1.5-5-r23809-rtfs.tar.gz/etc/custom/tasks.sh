#!/bin/sh

if grep -q 'tasks.sh' /etc/crontabs/root 2>/dev/null; then

	echo "$0 TASKS.SH REMOVE CRONTAB" > /dev/kmsg
	sed -i '\|/etc/custom/tasks.sh|d' /etc/crontabs/root 2>/dev/null

fi









exit 0



#sed -i '\|/etc/init.d/acme|d' /etc/crontabs/root









