use strict;
package Tie::Hash::NamedCapture;

our $VERSION = "0.10";

require XSLoader;
XSLoader::load(); # This returns true, which makes require happy.

__END__

