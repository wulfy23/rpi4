return {
	name = "odvr.nic.cz",
	label = _("ODVR (nic.cz)"),
	resolver_url = "https://odvr.nic.cz/doh",
	bootstrap_dns = "193.17.47.1,185.43.135.1,2001:148f:ffff::1,2001:148f:fffe::1",
	help_link = "https://www.nic.cz/odvr/",
	help_link_text = "nic.cz"
}
