return {
	name = "freedns.controld.com-p3",
	label = _("ControlD (Block Malware + Ads + Social)"),
	resolver_url = "https://freedns.controld.com/p3",
	bootstrap_dns = "76.76.2.3,2606:1a40::3",
	help_link = "https://kb.controld.com/tutorials",
	help_link_text = "ControlD.com"
}
