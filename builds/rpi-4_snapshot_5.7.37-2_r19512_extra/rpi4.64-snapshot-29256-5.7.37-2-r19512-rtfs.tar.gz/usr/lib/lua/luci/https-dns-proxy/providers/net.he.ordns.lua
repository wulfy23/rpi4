return {
	name = "ordns.he.net",
	label = _("Hurricane Electric"),
	resolver_url = "https://ordns.he.net/dns-query",
	bootstrap_dns = "74.82.42.42,2001:470:20::2",
	help_link = "https://forums.he.net/index.php?topic=3996.0",
	help_link_text = "he.net"
}
