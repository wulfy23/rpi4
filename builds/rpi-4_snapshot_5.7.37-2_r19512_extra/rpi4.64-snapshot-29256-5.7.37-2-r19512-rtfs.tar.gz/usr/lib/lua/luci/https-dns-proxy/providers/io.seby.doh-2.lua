return {
	name = "doh-2.seby.io",
	label = _("Seby DNS - AU"),
	resolver_url = "https://doh-2.seby.io/dns-query",
	bootstrap_dns = "45.76.113.31,139.99.222.72",
	help_link = "https://dns.seby.io/",
	help_link_text = "Seby.io"
}
