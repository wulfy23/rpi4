#!/bin/sh
i="$(basename $0)"
SNAME="$i"








PPI() {
	if ! grep -q 'DC:A6:32:56:31:77' /proc/cmdline 2>/dev/null; then
		return 0
	fi
	local i="${i}"
	if [ -z "${i}" ]; then
		i=$(basename $0)
	fi #||$1
	P="\$\$_$$:$(grep . /proc/$$/cmdline | tr -s '\n' ' ')"
	PP="ppid_$PPID:$(grep . /proc/$PPID/cmdline | tr -s '\n' ' ')"
	PPPID=$(grep . /proc/$PPID/stat | awk '{print $4}')
	PPP="pppid_$PPPID:$(grep . /proc/$PPPID/cmdline | tr -s '\n' ' ')"
echo "$i>PPI_P:$P" >/dev/console
echo "$i>PPI_PP:$PP" >/dev/console
echo "$i>PPI_PPP:$PPP" >/dev/console
sleep 5
}

#PPI











#echo "SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSs DEBUGHARDCODEDON shutdown.sh TOP" >/dev/console
#DEBUG=1










#################################################### #eval `grep ^RCDEBUG /root/wrt.ini 2>/dev/null`
################################ #@@@ DEBUG then SLOG=SLd<tmp||/>/SLf
SLOG="/$SNAME.debug" #if ! -z "..." && -d "..." #/usbstick #SLOG="/tmp/$SNAME.debug" #if ! -z "..." && -d "..." #/usbstick
SOUTPUTM="/dev/console"
SOUTPUTU="/dev/kmsg"

INIFILE="/root/wrt.ini"
if [ -f "$INIFILE" ]; then
    . "$INIFILE" || echo "$SNAME inifile: $INIFILE issue" > $SOUTPUTM
fi

if [ -n "$RCDEBUG" ]; then DEBUG=1; fi
[ -n "$DEBUG" ] && RCSLEEP=1
[ -n "$DEBUG" ] && logger -t $SNAME "DEBUG=1 $SLOG"








BACKSYS="/boot/backup"; mkdir -p $BACKSYS #OLD?
#LOGPERSIST (dirnotz)




#echo "shutdown.sh timingcheck start" > /dev/console














echSH() {

	DL=`date +%Y%m%d-%H%M%S`
	[ -n "$DEBUG" ] && echo "$i-$DL: ${*}" >> $SLOG #/shutdown.sh.debug

	echo "$i> ${*}" >> $SOUTPUTM #/dev/console

	sleep ${RCSLEEP:-0}
}



#############@case DEBUG in console||&&logfiletmp||&&logfileroot...etc.etc.
#############||case $SOUTPUTM in /dev/console /dev/kmsg *) if file ... ||stdout echo ||logger
### #echo "echSH-console-only@$i> ${*}" > /dev/console





echq() { echSH "echqcallfix||| ${*}"; }

###################### 20220135 tidyISH most calls are echSH ^commentselfexplanitory






################## 20220135 for all the -n DEBUG lines
echSHd() {

	[ -z "$DEBUG" ] && return 0
	echSH "${*}"
	sleep ${RCSLEEP:-0}

}










callerdbginfo() {



	echo "### PPID: $PPID $(ps w | awk '{print $1 " " $2 " " $3 " " $4 " " $5 " " $6 " " $7 " " $8}' | grep "^$PPID ")"
	echo "### \$\$: $$ $(ps w | awk '{print $1 " " $2 " " $3 " " $4 " " $5 " " $6 " " $7 " " $8}' | grep "^$$ ")"
	echo "init-DEBUGFILEis-$i-$DL: ${*} $SLOG"
	echo "init-NORMALFILEis-$i> ${*} $SOUTPUTM"
	echo "DBG $(basename $0) ${*} pid:$(echo $$) ppid:$(echo $PPID)"




	################################ shutdown.sh params:${*} DEBUGGING IS ON" > /dev/console
#	echo "### PPID: $PPID $(ps w | awk '{print $1 " " $2 " " $3 " " $4 " " $5 " " $6 " " $7 " " $8}' | grep "^$PPID ")"
#	echo "init-DEBUGFILEis-$i-$DL: ${*} $SLOG" > /dev/console #init-DEBUGFILEis-shutdown.sh-: shutdown /tmp/shutdown.sh.debug lol
	#@@@ SOUTPUTM is /dev/console :) :) :)
#	echo "init-NORMALFILEis-$i> ${*} $SOUTPUTM" > /dev/console


	########################################################################################## 
#	echo "DBG $(basename $0) ${*} pid:$(echo $$) ppid:$(echo $PPID)" >/dev/console

}

################ echo "### PPID: $PPID $(ps w | grep $PPID)"









if [ -n "$DEBUG" ]; then
	callerdbginfo >/dev/console
	callerdbginfo >>"${SLOG:-"/shutDBGFIXME"}"
fi

#20220135 moveintoabove [ -n "$DEBUG" ] && echq "DBG $(basename $0) ${*} pid:$(echo $$) ppid:$(echo $PPID)"



#[  228.281025] ffmpeg-aarch64[bg]> Download: ffmpeg method:git [ok]
#SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSs DEBUGHARDCODEDON shutdown.sh TOP
##################################### shutdown.sh params:plog psave DEBUGGING IS ON
### PPID: 1     1 root      1708 S    /sbin/procd
#   10 root         0 SW   [ksoftirqd/0]
#   11 root         0 IW   [rcu_sched]
























if [ -z "$1" ]; then
	echSH "[no-param1-exit]"; sleep 5; exit 0
fi
############ #20220135WASONnowcontinue?>NOPEherefor a reason dont need sleep tho?
#echSH "[no-param1-exit]"; sleep 5; exit 0












BOOTLOGd="/boot/backup/bootlogs"
DS="`date +%Y%m%d%H%M`"
















arewemounted() { #>custfunc.sh



	if [ "$(mount | grep ' /boot ' | grep '(rw' | grep -v grep | wc -l)" -eq 1 ] && \
    	[ "$(mount | grep ' / ' | grep '(rw' | grep -v grep | wc -l)" -gt 0 ]; then

		: #debugprint
		return 0
	else
		: #debugprint
	fi



	#case "${*}" in *boot* *rootfs* x 2


	WAITMAX=11
    while [ "$(mount | grep ' / ' | grep '(ro' | grep -v grep | wc -l)" -gt 0 ]; do
        WAITCNT=${WAITCNT:-0}
		WAITCNT=0
        echo "$i waiting for rw-rootfs: $WAITCNT" >/dev/console
        sleep 1; if [ "$WAITCNT" -gt "$WAITMAX" ]; then break; fi; WAITCNT=$((WAITCNT + 1))
    done
    if [ "$(mount | grep ' / ' | grep '(ro' | grep -v grep | wc -l)" -gt 0 ]; then
        echo "$i waiting for rw-rootfs: $WAITCNT giving up" >/dev/console; return 1 #exit 0
	fi

	if [ "$(mount | grep ' /boot ' | grep '(rw' | grep -v grep | wc -l)" -eq 0 ]; then
    	WAITMAX=11
		WAITCNT=0
	    	while [ "$(mount | grep ' /boot ' | grep '(rw' | grep -v grep | wc -l)" -eq 0 ]; do
            WAITCNT=${WAITCNT:-0}
            echo "$i waiting for rw-boot: $WAITCNT" >/dev/console
            sleep 1; if [ "$WAITCNT" -gt "$WAITMAX" ]; then break; fi; WAITCNT=$((WAITCNT + 1))
        done
    fi
    if [ "$(mount | grep ' /boot ' | grep '(rw' | grep -v grep | wc -l)" -eq 0 ]; then
        echo "$i waiting for rw-boot: $WAITCNT giving up" >/dev/console; return 2 #exit 0
	fi


}

#NONRPIneedsFIX















##################################################### um... too high || add logic || RCDEBUGLOGS=1 etc.
if [ -n "$RCDEBUG" ]; then
	mkdir -p "$BOOTLOGd"
	dmesg >> $BOOTLOGd/shutdown.sh-$1-dmesg-$DS
	logread >> $BOOTLOGd/shutdown.sh-$1-logread-$DS
fi
##################################################################################







gatherdebuginfo() {


if [ -n "$RCDEBUG" ]; then
	#ps w > /$0.testing.psw-on-shutdownatpersislogcalll
	echo "FIXME-LOGGINGTO/$0.abc" >/dev/console
	ps w > /$0.testing.psw-on-shutdownatpersislogcalll
fi

}





		





save_uptime() {

	local FN="save_uptime"

    #SECONDCALLBUG	
	if mount | grep ' / ' | grep -q '(ro'; then
		#echSH "$FN> rootfs is RO [$(cat /proc/$PPID/cmdline 2>/dev/null)]"
		return 1
	fi


	########################### #if [ "$1" = "shutdown" ] || [ "$1" = "upgrade" ]; then

	if [ ! -d "/restorefiles" ]; then echSH "$FN> no /restorefiles"; return 1; fi #echo "no /restorefiles"





	if [ -f "/tmp/.uptime.last.$(date +%Y%m%d%H%M)" ]; then return 1; fi #echSH "$FN> repeatcall PPID/cmdline persistentdata$"



	tDATE="$(date)"
	tUPt="$(uptime | awk '{print $2 " " $3 " " $4 " " $5 " " $6" " $7 " " $8 " " $9}')"
	echo "$1 $tDATE $tUPt" > /restorefiles/.uptime.last

	touch /tmp/.uptime.last.$(date +%Y%m%d%H%M)
	
	
	return 0

}

#local kSECSn="$(sed 's/[. ].*//' /proc/uptime)"
#echo "$kSECSn" > /tmp/.uptime.last.$(date +%Y%m%d%H%M)

#kSECSn="$(sed 's/[. ].*//' /proc/uptime)"
#echSH "saving last uptime /restorefiles/.uptime.last [1=$1 2=$2]"













if grep -q 'DC:A6:32:56:31:77' /proc/cmdline 2>/dev/null; then
	if echo "$(cat /proc/$PPID/cmdline 2>/dev/null)" | grep -q "/sbin/procd$"; then
		: #probably CRON cron=/sbin/procd
		###echo "OFFMEMNTxyz> shutdown.sh ${*} [$(cat /proc/$PPID/cmdline 2>/dev/null)] $(cat /proc/$$/cmdline)" >/dev/console
	elif echo "$(cat /proc/$PPID/cmdline 2>/dev/null)" | grep -q "crond"; then
		: #iscron WONThitTHIS
	else
		#bash echo "MNTxyz> shutdown.sh ${*} [$(cat /proc/$PPID/cmdline 2>/dev/null)]" >/dev/console
		echSHd "MNTxyz> shutdown.sh ${*} [$(cat /proc/$PPID/cmdline 2>/dev/null)]" >/dev/console
	fi
fi




#MNTxyz> shutdown.sh plog psave [/usr/sbin/crond-f-c/etc/crontabs-l9]











#################################################IF!TMPFS? HACK UNTIL/IF WE ACTUALLY SUPPORT $1 halt|reboot

if [ "$1" != "plog" ]; then #reboot/halt calls this twice?


case "$(cat /proc/$PPID/cmdline 2>/dev/null)" in
	*"/usr/sbin/halt")
		ISHALT=1
	;;
	*"/usr/sbin/reboot")
		ISREBOOT=1
	;; #PPID: 11555 11555 root      1256 SN   {reboot} /bin/sh /usr/sbin/reboot
esac










	#################!!!!!!!!!!!!!!!!!!! TESTING LOGICONLYBECAREFULL with PARAM1 ISREBOOT/HALT
	if [ "$1" = "reboot" ]; then
		echo "###################### fakereboot"
		ISREBOOT=1
		fACTION="plog"
		sleep 5
	fi








	if [ ! -z "$ISREBOOT" ]; then
		save_uptime "reboot"
		RUNDIRs="reboot halt shutdown"
	fi
	if [ ! -z "$ISHALT" ]; then
		save_uptime "halt"
		RUNDIRs="reboot halt shutdown"
	fi
		
	if [ "$1" = "shutdown" ]; then
		save_uptime "$1"
		RUNDIRs="reboot halt shutdown"
	fi
	if [ "$1" = "upgrade" ]; then
		save_uptime "$1"
		RUNDIRs="reboot halt shutdown upgrade"
	fi





	#if [ "$1" = "shutdown" ] || [ "$1" = "upgrade" ]; then
	#	save_uptime "$1"
	#fi ####INSAVENOW if [ -d "/restorefiles" ]; then


else

	#wemust be plog boot or plog psave or manualmaybeNOSUPP
	if [ -n "$DEBUG" ]; then
		###[ -n "$RCDEBUG" ]; then 2022 find fasterdebugfunc!!!
		echSH "NOT A REBOOT || HALT || SHUTDOWN || UPGRADE"
		#>>> if [ "$1" != "plog" ]; then #reboot/halt calls this twice?
	fi

fi

#if [ ! -z "$ISREBOOT" ]; then save_uptime "reboot"; fi
#if [ ! -z "$ISHALT" ]; then save_uptime "halt"; fi
#if [ "$1" = "shutdown" ] || [ "$1" = "upgrade" ]; then
#	save_uptime "$1"
#fi ####INSAVENOW if [ -d "/restorefiles" ]; then
#else

	#wemust be plog boot or plog psave or manualmaybeNOSUPP
#	if [ -n "$DEBUG" ]; then
		###[ -n "$RCDEBUG" ]; then 2022 find fasterdebugfunc!!!
#		echSH "NOT A REBOOT || HALT || SHUTDOWN || UPGRADE"
		#>>> if [ "$1" != "plog" ]; then #reboot/halt calls this twice?
#	fi

#fi


























################################# JUSTFORDEBUG/DETECTIONCHECKFORNOW i.e. CRON vs INIT/INIT.D
#if [ "$1" = "plog" ]; then #reboot/halt calls this twice?
case "$(cat /proc/$PPID/cmdline 2>/dev/null)" in
	*"/sbin/procd")
		#NEVERUSED ISCRONTABBY=1
		[ -n "$DEBUG" ] && echSH "20220135 DBG procd probably CRON"
	;;
esac






















#/bin/sh/etc/rc.common/etc/rc.d/K89persistentdatashutdown
####### hmmm must call by itself @ K98 stop >  MNTxyz> shutdown.sh plog psave [/sbin/procd]
#NOT IN CRONTABs












####################################################################### reboot
#MNTxyz> shutdown.sh plog [/bin/sh/usr/sbin/reboot]
#MNTxyz> shutdown.sh shutdown [/bin/sh/usr/sbin/reboot]
#abc> shutdown.sh shutdown [/bin/sh/usr/sbin/reboot]

#######################################################################
#@2021 $0 plog psave
#@2021?[ -x /etc/init.d/persistentlucistatistics ] && /etc/init.d/persistentlucistatistics stop >/dev/null 2>/dev/null


#[  665.363739] /etc/init.d/persistentdata: stop sync /tmp/dlwrapper > /boot/dlwrapper
#[  666.857408] /etc/custom/dca632563177.sh shutdown [ok]
#[  666.899068] calling sync
#[  670.569794] calling umount -a












##########save_uptime "$1"
#if [ "$1" = "shutdown" ] || [ "$1" = "upgrade" ]; then
#		####INSAVENOW if [ -d "/restorefiles" ]; then
#			save_uptime "$1"
#		### fi
#	fi


			




#############################################################################################


			#tDATE="$(date)"
			#tUPt="$(uptime | awk '{print $2 " " $3 " " $4 " " $5 " " $6" " $7 " " $8 " " $9}')"
			#echo "$tDATE $tUPt" > /restorefiles/.uptime.last

			#echSH "saving last uptime /restorefiles/.uptime.last [1=$1 2=$2]"
			##################tUPt="$(uptime)"
			################echo "$(date; uptime)" > /restorefiles/.uptime.last
			################################################### UPTIMEn="$(date; uptime)"




##################################################################################################
#	shutdown.sh-shutdown shutdown
#shutdown.sh> DBG not saving last uptime /restorefiles/.uptime.last [1=plog 2=psave]
#shutdown.sh> saving last uptime /restorefiles/.uptime.last [1=plog 2=]
#shutdown.sh> saving last uptime /restorefiles/.uptime.last [1=shutdown 2=]

	#20220129 and rc.custom NOTE: shutdown shutdown by rebootwrapper
    #if [ ! -z "$2" ] && [ "$2" != "boot" ] && [ "$2" != "psave" ]; then
    #if [ "$1" != "boot" ] && [ "$1" != "psave" ]; then

#	if echo "${*}" | grep -wq "boot" || \
#    	echo "${*}" | grep -wq "psave"; then
#
#		:
#			echSH "DBG not saving last uptime /restorefiles/.uptime.last [1=$1 2=$2]"
#	else










#set -x










#@@@ /etc/custom/reboot if reboot



if [ ! -z "$ISREBOOT" ] || [ ! -z "$ISHALT" ] || [ "$1" = "upgrade" ] || [ "$1" = "shutdown" ]; then






	:


thisconditionalisimportantbuttestingrundirsatend() {





	################ TBA just make a list for end and func w FF? #for runDIR in $RUNDIRs; do
	if [ -d /etc/custom/reboot ]; then
		##########echSH "/etc/custom/reboot/* [run]"; sleep ${RCSLEEP:-0} ############################## #$ecmd
		### echSH "20220135 silent test ON /etc/custom/reboot/* [run]"; sleep ${RCSLEEP:-0} ############################## #$ecmd
		echSHd "20220135 silent test ON /etc/custom/reboot/* [run]"; sleep ${RCSLEEP:-0} ############################## #$ecmd
			for z in /etc/custom/reboot/*; do

				if [ "$(basename $z)" = "NOTES" ]; then continue; fi
				if echo "$z" | grep -q "disabled$"; then continue; fi

				#############echSH "${z} [run]"; sleep ${RCSLEEP:-0} ### $ecmd "dbg-reboot-rundor: $z"
				echSHd "20220135silenttestON ${z} [run]"; sleep ${RCSLEEP:-0} ### $ecmd "dbg-reboot-rundor: $z"
                sh "${z}"
			done
	else
		echSHd "/etc/custom/reboot/ [nodir]" ######$ecmd
	fi



}












	#if [ "$1" = "shutdown" ]; then #upgrade case has section for this || [ "$1" = "upgrade" ]; then









#else DBG what other calls do we have find elsewhere in script


fi














################################### 2022rundir for reboot or halt (aka not upgrade)
############### not 'plog psave' or psave or plog
########################################################### if [ ! -z "$ISREBOOT" ] || [ ! -z "$ISHALT" ]; then


























#1=sACTION plog||etc
#2=@@@sysstate cronsnap||boot||shutdown||other
#3=caller? $0 ... rc.d = fullpath...

























if [ -z "$fACTION" ] && [ ! -z "${1}" ]; then
	fACTION="${1}"

elif [ -z "$fACTION" ]; then

	#WAS else #for fake ISREBOOT
	fACTION="noparamsgiven" #@add all the ISREBOOT carp from save_uptime here ###default case is psave?


fi









########### case "$1" in 20220135 ISREBOOT or other not called as PARAM1 allow fixup for common case
#hmmm case had no psave > 'plog psave' hitting case-default $*? below 



########################################################################## CRON
#[  228.281025] ffmpeg-aarch64[bg]> Download: ffmpeg method:git [ok]
#SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSs DEBUGHARDCODEDON shutdown.sh TOP
##################################### shutdown.sh params:plog psave DEBUGGING IS ON
### PPID: 1     1 root      1708 S    /sbin/procd
#   10 root         0 SW   [ksoftirqd/0]
#   11 root         0 IW   [rcu_sched]













case "$fACTION" in



    fbootnoncommunityrestoretargz)
        :
        #called by? rc.local? early? late? < uci-defaults
        #no .firstboot && rc.local is stock &&|| profile.d/no-ashprofile.sh "isfboot" && "isnoncomm" then rclocal profile.d ...
    ;;




    install) #disabledorenabled ############################################################# UNUSED
		echSH "[heredocs-initdhooks-disabled-old]"; sleep ${RCSLEEP:-0}
		#writeinitdshutdownlate
		#writeinitdshutdownearly
	;;
    late)
		echSH "[late-ping]"; sleep ${RCSLEEP:-0}
		echSH "$(mount)"; logme "$(ps w)"
		echSH "$(pgrep -P 1 -a)"
	;;
	early)
		echSH "[early-ping]"; sleep ${RCSLEEP:-0}
		echSH "$(mount)"; logme "$(ps w)"
		echSH "$(pgrep -P 1 -a)"
	;;
    ############################################################# UNUSED


    #@@@ wrapper||&&cron> altsnap) persiststop persiststart x 2!!!>>> #@@@ persistX altsnap



    upgrade) #statisticsave|upgrade)




        #if uci show sqm | grep -q rpi4.qos; then #&& wrt.ini IPSET_SAVE
        #    if grep -q "^RPI4QOS_IPSETPERSIST" /root/wrt.ini 2>/dev/null; then
        #        echo "shutdown.sh upgrade ipsetsave /etc/init.d/sqm stop 2>/dev/null 1>/dev/null" > /dev/console
        #        echo "$(/etc/init.d/sqm stop)" > /dev/console
        ##########        #/etc/init.d/sqm stop 2>/dev/null 1>/dev/null
        #    fi
        #fi


















		#if [ ! -d /tmp/rrd ]; then #@BROAD>>>per-service-stop||below all >/dev/null
        #		echSH "$SSNAME /tmp/rrd [nothing to backup]"; exit 0
		#else
            #20200911-POWERFAIL-ish EXTRA KEYPOINT PRINTS###########################################
            #[ -n "$DEBUG" ] && echSH "$SNAME> stopping nlbwmon|lucistats|collectd for clean data"
            echSH "stopping nlbwmon|lucistats|collectd for clean data"; #sleep 1
            ########################################################################################
            #20200911@@@~ifrunning?savingoveritself?whilestopped???


		if pidof nlbwmon 1>/dev/null; then
			[ -n "$DEBUG" ] && echSH "[running:$(pidof nlbwmon)]"
			NLBRUN=1
		else
			[ -n "$DEBUG" ] && echSH "prestop-nlbwmon [notrunning:$(pidof nlbwmon)]" #NLBRUN=0
		fi




		if [ ! -z "$NLBRUN" ]; then
			[ -x /etc/init.d/nlbwmon  ] && /etc/init.d/nlbwmon stop >/dev/null 2>&1
			while [ ! -z "$(pidof nlbwmon 2>/dev/null)" ]; do
				nlbWAITcnt=${nlbWAITcnt:-"1"}
				echSH "stop> nlbwmon [stop-wait:$nlbWAITcnt]"; sleep 1
				nlbWAITcnt=$(($nlbWAITcnt + 1))
				if [ "${nlbWAITcnt}" -eq 35 ]; then
					echSH "stop> nlbwmon [stop-wait:$nlbWAITcnt] maxxed out"
					break
				fi
			done

            nlbw -c commit >/dev/null 2>/dev/null; sleep 2 #was3
            nlbw -c commit >/dev/null 2>/dev/null; sleep 2 #was3

			/etc/init.d/nlbwmon stop >/dev/null 2>/dev/null


			#NEWTESTINGTHIS->technically this is all we need to call? unless sysupgrade->backup-caseetal
			#then again realdir is in sysupgrade.conf so probably not needed... in case failed sysup

			#@@@ wrt.ini enabled etc ... >>> @psave call only

			[ -x /etc/init.d/persistentnlbwmon ] && /etc/init.d/persistentnlbwmon stop >/dev/null 2>/dev/null
			#@@@ persistnlb stop

		fi











		if pidof collectd 1>/dev/null; then
		    [ -n "$DEBUG" ] && echSH "statsrunning> NOTEHACK@collectd-pidof [stop]"; #sleep 1
            STATRUN=1
        fi

        /etc/init.d/luci_statistics stop >/dev/null 2>/dev/null
        /etc/init.d/collectd stop >/dev/null 2>/dev/null





	    #ALSONEW... in case of failed upgrade
	    [ -x /etc/init.d/persistentlucistatistics ] && /etc/init.d/persistentlucistatistics stop >/dev/null 2>/dev/null






        #(/etc/init.d/nlbwmon stop >/dev/null 2>/dev/null) &
        #(/etc/init.d/luci_statistics stop >/dev/null 2>/dev/null) &
        #(/etc/init.d/collectd stop >/dev/null 2>/dev/null) &
		#sleep 2 #??? dataintegrityneed>?wason:sleep 5

            #######@@@ ~!call persistl/n but sysupgrade stores real data dir aka...
            #######/etc/init.d/persistentlucistatistics; /etc/init.d/persistentnlbwmon
            ########ensure nothing is there on fboot||realbigger then snapitthen
            #######thiswouldneedextralogicinboot aka firstboot + restored data -lt 200b + backup WHERE??? nopersistentstorage!
		#fi



        if [ ! -z "$NLBRUN" ]; then
			[ -n "$DEBUG" ] && echSH "restart-2021-test-sysup-Tfix> nlbwmon [start]"; #sleep 1
            /etc/init.d/nlbwmon start >/dev/null 2>/dev/null
        fi

        if [ ! -z "$STATRUN" ]; then #@@@NOTE restart because 'start' issue re order (lucistat restart is enough leave collect)
			[ -n "$DEBUG" ] && echSH "restart-2021-test-sysup-Tfix> stats [start-re]"; #sleep 1
            /etc/init.d/collectd restart >/dev/null 2>/dev/null
            /etc/init.d/luci_statistics restart >/dev/null 2>/dev/null
	    fi

		








testingrundirsatend() {


		#20220115 NOTCALLED FROM sysupgrade? @ add ~macrun_similar_DIR /etc/custom/upgrade################3
		#20220115 NOTCALLED FROM sysupgrade? @ add ~macrun_similar_DIR /etc/custom/upgrade################3
		#20220115 NOTCALLED FROM sysupgrade? @ add ~macrun_similar_DIR /etc/custom/upgrade################3
		###FOR 012-plogcleanup ########################echo "shutdown.sh upgrade 2022 rundirTEST" >/dev/console
		#echSH "shutdown.sh upgrade 2022 rundirTEST" >/dev/console
		if [ -d /etc/custom/upgrade ]; then
			#####################$ecmd "/etc/custom/upgrade/* [run]"; sleep ${RCSLEEP:-0}
			echSH "/etc/custom/upgrade/* [run]"; sleep ${RCSLEEP:-0}
				for z in /etc/custom/upgrade/*; do
                	#####################$ecmd "$z"
					SCRIPTret=
                	sh "${z}"; SCRIPTret=$?
					echSH "$z:$SCRIPTret"

					###########!!!!!!!! probably add RETVAL and pass back to sysupgrade stop here
					######### exit ${THERETVAL:-"0"}
					case "$SCRIPTret" in
						0) : ;;
						*)
							### echSH "$z:$SCRIPTret"
							THERETVAL=11
						;;
					esac

				done
		else
			######################$ecmd "/etc/custom/upgrade/ [nodir]"
			echSH "/etc/custom/upgrade/ [nodir]"
		fi
		#20220115 NOTCALLED FROM sysupgrade? @ add ~macrun_similar_DIR /etc/custom/upgrade################3
		#20220115 NOTCALLED FROM sysupgrade? @ add ~macrun_similar_DIR /etc/custom/upgrade################3
		#20220115 NOTCALLED FROM sysupgrade? @ add ~macrun_similar_DIR /etc/custom/upgrade################3




}













    ;;

    ################################################################ not much / anything is calling this anymore?
    ################################################################ !@reboot only halt?
    ################################################################ wrapper calls plog only I think

    #shutdown was initally called from... persistdata?
    #now wrapper calls... plog... need to log caller...





	#plog@persistendata shutdown ${UPGRADED}
    shutdown)




		#ADDEDpreCASEonMAINT echo "abc> shutdown.sh ${*} [$(cat /proc/$PPID/cmdline 2>/dev/null)]" >/dev/console
		gatherdebuginfo "$1"
		#############echo "abc> shutdown.sh ${*} [$(cat /proc/$PPID/cmdline 2>/dev/null)]" >/dev/console
		############echo "shutdown.sh-shutdown ${*}" >/dev/console
		############echo "abc> shutdown.sh ${*}" >/dev/console





		#@2021 $0 plog psave
		#@2021?[ -x /etc/init.d/persistentlucistatistics ] && /etc/init.d/persistentlucistatistics stop >/dev/null 2>/dev/null



        #if uci show sqm | grep -q rpi4.qos; then #&& wrt.ini IPSET_SAVE
        #    if grep -q "^RPI4QOS_IPSETPERSIST" /root/wrt.ini 2>/dev/null; then
        #        ###/etc/init.d/sqm stop 2>/dev/null 1>/dev/null
        #        echo "shutdown.sh shutdown ipsetsave /etc/init.d/sqm stop 2>/dev/null 1>/dev/null" > /dev/console
        #        echo "$(/etc/init.d/sqm stop)" > /dev/console
        #    fi
        #fi

	
		
		
		
		
		
	


thiISaRUNdirNOW() {	
		
		###20220125 reboot was not running shutdown rundir MOVE all rundir to function me things	
		################ TBA just make a list for end and func w FF? #for runDIR in $RUNDIRs; do
		
		
		if [ -d /etc/custom/shutdown ]; then
			##########echSH "/etc/custom/reboot/* [run]"; sleep ${RCSLEEP:-0} ############################## #$ecmd
			### echSH "20220135 silent test ONSHUT /etc/custom/shutdown/* [run]"; sleep ${RCSLEEP:-0} ############################## #$ecmd
			echSHd "20220135 silent test ONSHUT /etc/custom/shutdown/* [run]"; #sleep ${RCSLEEP:-0} ############################## #$ecmd
			for z in /etc/custom/shutdown/*; do

				if [ "$(basename $z)" = "NOTES" ]; then continue; fi
				if echo "$z" | grep -q "disabled$"; then continue; fi

				#############echSH "${z} [run]"; sleep ${RCSLEEP:-0} ### $ecmd "dbg-reboot-rundor: $z"
				echSHd "20220135silenttestONSHUT ${z} [run]"; sleep ${RCSLEEP:-0} ### $ecmd "dbg-reboot-rundor: $z"
                sh "${z}"
			done
		else
			echSH "/etc/custom/shutdown/ [nodir]" ######$ecmd
		fi



}






    ;;









	############################################################################## plog
    plog)
	





        if [ -z "${LOGPERSIST}" ]; then
			#@?> 20220125 document ADDED?date? 202112ish?
			echSHd "20220135 DBG shutdown.sh plog LOGPERSIST-z [off] 20220113 testing"
			$ecmd "202111ISH DBG shutdown.sh plog LOGPERSIST-z [off] 20220113 testing"
			exit 0
		fi















	################################### WHOOPS MAY HAVE TRIGGERED FSCK@rootfs
	#if [ -z "$LOGPERSIST" ]; then
		#@@@>logONCE
		#@@@>crontabs/root 
	#	echo "20210399-LOGPERSIST[off] exit early hack" >/dev/console
	#	exit 0
	#fi

		######################################################################################
		##sed -i '\|/etc/init.d/acme start|d' /etc/crontabs/root
		######################################################################################
		#if [ -f "/etc/crontabs/root" ] && grep -q '/etc/init.d/acme' /etc/crontabs/root; then
		#ACMELINE=$(grep -n acme /etc/crontabs/root | cut -d':' -f1)
		#echo "ACMELINE: $ACMELINE"
		#sed -i "${ACMELINE} s!^!#!g" /etc/crontabs/root
		#####################################################################################












	#echo "shutdown.sh-DBG-2021-FISHPLOG ${*}" >/dev/console




	if [ "$2" = "boot" ]; then
		ISBOOT=1
	fi #@init.d/persistentdata $0 plog boot
	if [ "$2" = "psave" ]; then
		ISPSAVE=1
	fi #@cron plog psave









	################!!!!!!!! PSAVEDIR@persistdata is the parentfolder for 'architecture' aka /bootCOPIEDLINEFORREF
	#echo "REMOVEME(plog?)synologicHECK calling-are-we-mounted params:${*}" >/dev/console
	#sleep 2


	arewemounted || PSAVEISSUES="${PSAVEISSUES} not-mounted" #exit 0 #arewemounted #usedtoexits #@@@"boot rootfs"

	if [ -z "$LOGPERSIST" ]; then
            PSAVEISSUES="${PSAVEISSUES} LOGPERSIST[empty]" #echSH "logpersist [empty]"
            #echo  "LOGPERSIST= EMPTY > exit 0"; exit 0
    else
	        : #echo  "LOGPERSIST: $LOGPERSIST"
    fi







	#gatherdebuginfo "$1" #THISDOESNOTHIN?2021TURNOFF@ro earlyboot
	################################ps w > /$0.PLOG.ATSHUTDOWNSH.testing.psw-on-shutdownatpersislogcalll






	eval $(grep '^localversion=' /etc/custom/buildinfo.txt 2>/dev/null)
	if [ -z "$localversion" ]; then localversion="unknown"; fi

	systemLF=$(uci get system.@system[0].log_file 2>/dev/null)
    if [ ! -z "$systemLF" ]; then #NOTUSED
		systemLFlines=$(cat $systemLF | wc -l)
	fi #echSH "systemLOGfile: $systemLF [$systemLFlines]" #@POSSIBLEEXITHERE




	############## 20220135WASON inaccurateandaddingsumminglogic at topcase and better summMSG
	#[ -n "$DEBUG" ] && echSH "called from wrapper: ${*}" #echSH "called from init.d persistdata: ${*}"






	if [ ! -z "$PSAVEISSUES" ]; then echSH "psave issues: $PSAVEISSUES"; exit 0; fi

	#NOWLETSGETHAPPENING



		
	
	#########################################################320220302 for sysinfo.sh hostreport rebooted
	if [ ! -z "$ISPSAVE" ]; then
		if [ -f /tmp/dhcp.leases ]; then
			cp -u /tmp/dhcp.leases /restorefiles/
		fi

		if [ -f /tmp/hosts/odhcpd ]; then
			cp -u /tmp/hosts/odhcpd /restorefiles/odhcpd.leases
		fi
	
	fi
	#####################################################################################################







	if [ ! -z "$ISPSAVE" ]; then #???

		[ -n "$DEBUG" ] && echSH "plog> touching /etc/banner 20220135"


		bannerlasttime=$(date -r /etc/banner)
		touch /etc/banner
		bannernewtime=$(date -r /etc/banner)

	fi



		############################################################################
			#echo "$0 touch /etc/banner [$bannerlasttime>$bannernewtime]" > /dev/console
			: #202107 QUIET	
		####################### @sysfixtime speedups ISNOTMOUNTED>reboot
		####################### topofthisscriptpostumount>rebootwrapper+here
		#@@@dhcp-ra?>toooften
		############################################################################
		#date -r /etc/banner -R #AEST>+10
		#date -r /etc/banner -I '+%Y%m%d_%H%M%S'
		############################################################################
	
			














        mkdir -p "${LOGPERSIST}" || return 0
        DSTAMP=$(date +%Y%m%d%H%M)
        LOGLINES=$(logread | wc -l)

        #echo "DBG dumping ${LOGPERSIST}/plogread-${DSTAMP}.log lines:$LOGLINES" > /dev/console && sleep 2

    if [ ! -f /tmp/.plogname ]; then
        OUTFILE="${LOGPERSIST}/plogread-${DSTAMP}-"
        if [ ! -z "${2}" ]; then OUTFILE="${OUTFILE}${2}-"; fi
        OUTFILE="${OUTFILE}${localversion}.log"
		echo $OUTFILE > /tmp/.plogname
	else
		OUTFILE=$(cat /tmp/.plogname)
	fi

	if [ ! -f "$OUTFILE" ]; then touch $OUTFILE; fi #@NOWPRETOUCHINGTHIS
	oLINES=$(cat $OUTFILE | wc -l)



	if [ ! -z "$ISBOOT" ]; then #@&&enabled



		echo "plog-saved-to: /boot/plog ${OUTFILE}" > /dev/kmsg #||logger
		#scrape up the remaining boot messages in case of power loss or no init.d/done/rc.local call
		(sleep 250 && /etc/custom/shutdown.sh plog psave) & #bonus-effect-will-call-sync

		
		######################################################experimental2021ish
		#needs_scraper>done? 20220135scraper@upgrade/rundir 012 plogclean&&fboot
		#logic min 210seconds(150+)
		(sleep 230 && dmesg > $(dirname $OUTFILE)/pdmesg-${DSTAMP}-${localversion}.log) &


	fi



	if [ -f "${OUTFILE}" ]; then #incasemanuallydeletedandnamefromFLAGFILE
			if [ ! -z "$SHUTVERBOSE" ]; then #DOESNOTEXISTYETBUTALLTHISSTUFFISINPOSTMESSAGE
				echSH "pre-dump-size:$(du -cs ${OUTFILE} 2>/dev/null | head -n1) flines:$oLINES"
    		fi
	fi





	logfilter() {
		while read FISH; do
		case "${FISH}" in
			*"successfully loaded"*) :; ;; #collectdrubbush
			#*"Exiting normally."*) :; ;; #collectdrubbush
			*) echo $FISH; ;;
		esac
		done
	}
	logread | logfilter > /tmp/LOG #logread > /tmp/LOG



    nLINES=$(sed 'H;/LOGSAVED/h;$!d;x' /tmp/LOG | grep -v 'LOGSAVED' | wc -l)
    sed 'H;/LOGSAVED/h;$!d;x' /tmp/LOG | grep -v 'LOGSAVED' >> "${OUTFILE}"
	logger LOGSAVED

	rm /tmp/LOG 2>/dev/null




    if [ -z "$ISBOOT" ]; then
		#echo "shut.sh sync isboot:${ISBOOT:-"no"} ispsave:${ISPSAVE:-no}" >/dev/console ### 202107 QUIETAGAIN		
		DOSYNC=1 #sync
	fi
    #@@@@@@@@@@@@@ NOTETHISSHOULDBEONinit.dbootonly 2021OFFNOFIX@somethingearlyneedingtowrite?HIGHDELAYS sync
    #######echo "shut.sh SKIP-SYNC-POST-QUICKTEST" >/dev/console
	#NOPE@bootOROTHER-MOVEDOWNAFTERPLOGSYNC #####20210219tryagain #sync





	#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 202107IMPORTANTBUTNOISY #QUIET # FIXUPforDAILYloggerFROMtmporSOMETHING
	#oLINESN=$(cat $OUTFILE | wc -l)
	#echSH "post-dump-size:$(du -cs ${OUTFILE} 2>/dev/null | head -n1) flines:$oLINESN[$nLINES]"
	#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 202107IMPORTANTBUTNOISY









	######### FROM REBOOTWRAPPER BUT WOULD MISSCRON / POWERLOSS ETC #@@@RESTOREFILES #@@@ if -d /restorefiles
	################?CRON/SYSUP.CONFaddsHANDLED@?


	mkdir -p /restorefiles/plog
    cp -urf ${LOGPERSIST}/* /restorefiles/plog
	cp -urf /restorefiles/plog/* ${LOGPERSIST}/ #HAX-COPYNONEXISTBAK

	[ -n "$DEBUG" ] && echSH "cp -urf LOGPERSIST:${LOGPERSIST}/* /restorefiles/plog" #20220135
	[ -n "$DEBUG" ] && echSH "cp -urf /restorefiles/plog/* LOGPERSIST:${LOGPERSIST}/" #20220135





    if [ -z "$ISBOOT" ]; then
		#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 202107IMPORTANTBUTNOISY
		###############QUIET
		#echo "shutdown.sh syncing $LOGPERSIST/ and /restorefiles/plog [sync]" > /dev/console
		#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 202107IMPORTANTBUTNOISY

		DOSYNC=1

	else
		echo "shutdown.sh syncing $LOGPERSIST/ and /restorefiles/plog [nosync]" > /dev/console
	fi #20210225TESTWRAPPERHERE-SKIP-SYNC-ONBOOT 2021OFFNOFIX@somethingearlyneedingtowrite?HIGHDELAYS sync






	if [ ! -z "$DOSYNC" ]; then
		[ -n "$DEBUG" ] && echSH "syncing..."
		sync
	fi







	echSHd "DBG_RETURN 0 WASHERE and EXITS!"
	################# [ -n "$DEBUG" ] && echSH "DBG_RETURN 0 WASHERE and EXITS!"

	#!!!!!!!!!!!!!!!!!!!!!!!!! MAYHAVEBEENIMPORTANT!!!!!!!!!!!! 20220135
	#return 0 #|| continue &&||shift? #20220135 return to where? #@?> exit ${THERETVAL:-"0"}




    ;;

	
	####################################################################################################################
	#init.d/persistdata?>LOGPERSIST? ######################################## init.d/persistdata boot|shutdown ~upgraded
                #LOGPERSIST (dirnotz)
		#PSAVEDIR@persistdata is the parentfolder for 'architecture' aka /boot
		#NEEDS CRONADD FROM INITD > added in 73-addcron
		#has rebootwrapper /boot > /restore files cp -u @@@NEEDS LOGPERSIST and LOGDIR vars
        	#=DIR if [ -z "$LOGPERSIST" ]; then
        #@@@ NOTANYMORE $2 cronsnap > dump + logread FLUSH? #@@@boot???rotate||sizecheck||aboveindbgdumps???
	###################################################################################################################







    boot)
		[ -n "$DEBUG" ] && echSH "called from init.d persistdata: ${*}"
        echSH "DBGANYONECALLINGBOOT> called from init.d persistdata: ${*}" #20220135ISONthisisnevercalleditsPARAM2
    ;;






	*)
        [ -n "$DEBUG" ] && echSH "case-default:$1 [o]]"; sleep ${RCSLEEP:-0}
		#echSH "case-default:$1 [o]]"; sleep ${RCSLEEP:-0}
	;;

esac






########## 2022settingafallbackforawhileadditheretoo *) #fACTION="noparamsgiven" will matchanyway for now see case top










#if [ -z "$RUNDIRs" ]; then echSHd "PHASE2 RUNDIRs [empty:$1 $2]"; fi #1plog
for runDIR in $RUNDIRs; do

	runDIRff="/tmp/.rundir.shutdown.${runDIR}"

	if [ ! -d /etc/custom/${runDIR:-"FISH"} ]; then echSHd "RUNDIR: /etc/custom/$runDIR/ [nodir]"; continue; fi
	if [ "$(ls -1 /etc/custom/$runDIR/ | wc -l)" -eq 0 ]; then
		echSHd "RUNDIR: /etc/custom/$runDIR/ [empty]"; continue
	fi
	if [ -f "$runDIRff" ]; then echSHd "RUNDIR: $runDIR ff:$runDIRff [already_ran]"; continue; fi

	echSHd "RUNDIR: $runDIR"	
	if [ -d /etc/custom/${runDIR:-"FISH"} ]; then
		echSHd "20220135 silent test ON /etc/custom/$runDIR/* [run]"; sleep ${RCSLEEP:-0}

		for z in /etc/custom/$runDIR/*; do

			if [ "$(basename $z)" = "NOTES" ]; then continue; fi
			if echo "$z" | grep -q "disabled$"; then continue; fi

			echSHd "20220135silenttestON ${z} [run]"; sleep ${RCSLEEP:-0} ### $ecmd "dbg-reboot-rundor: $z"
                	sh "${z}"
		done

	#else #	echSH "/etc/custom/$runDIR/ [nodir]" ######$ecmd
	fi
	touch "$runDIRff"
done












	#if [ "$1" = "shutdown" ]; then #upgrade case has section for this || [ "$1" = "upgrade" ]; then









#done


############################## 20220135
############################## 20220135
############################## 20220135
############################## 20220135
############################## 20220135
############################## 20220135














[ -n "$DEBUG" ] && echSH "$SNAME $1 [complete]"



exit ${THERETVAL:-"0"}












#shutdown.sh> called from wrapper: plog boot
#[ 2160.753138] plog-saved-to: /boot/plog /boot/plog/plogread-202202021756-boot-5.0.67-35.log
#shutdown.sh syncing /boot/plog/ and /restorefiles/plog [nosync






########################## 2022BASEBITS



###################### ####################### @sysfixtime speedups ISNOTMOUNTED>reboot
#date -r /etc/banner -R #AEST>+10
#bannerlasttime=$(date -r /etc/banner)
#touch /etc/banner
#bannernewtime=$(date -r /etc/banner)
#echo "$0 touch /etc/banner [$bannerlasttime > $bannernewtime]" > /dev/console




############################################################################
#[ -n "$DEBUG" ] && echSH "dbg sleep 3" && sleep 1








