return {
	name = "dns.comss.one",
	label = _("Comss.ru DNS (West)"),
	resolver_url = "https://dns.comss.one/dns-query",
	bootstrap_dns = "92.38.152.163,93.115.24.204,2a03:90c0:56::1a5,2a02:7b40:5eb0:e95d::1"
}
