return {
	name = "dns.tuna.tsinghua.edu.cn",
	label = _("Tsinghua University Secure DNS - CN"),
	resolver_url = "https://dns.tuna.tsinghua.edu.cn:8443/dns-query",
	bootstrap_dns = "208.67.222.222,208.67.220.220",
}
