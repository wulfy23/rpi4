#!/bin/sh
#FORCOLOR rootfsexpandFIX1
#somethingsomethingsomething


. /lib/functions.sh

REQUIRE_IMAGE_METADATA=1

# copied from x86's platform.sh






vRPT() {

	echo "${1}" >> /tmp/.upgrade.rpt


}





platform_check_image() {

	local diskdev partdev diff

	[ "$#" -gt 1 ] && return 1

	export_bootdevice && export_partdevice diskdev 0 || {
		echo "Unable to determine upgrade device"
		return 1
	}

	get_partitions "/dev/$diskdev" bootdisk





	#extract the boot sector from the image
	##############################################################################
	#ORIGINAL get_image "$@" | dd of=/tmp/image.bs count=1 bs=512b 2>/dev/null
	##############################################################################
	#GETIMAGE NO2NULL #get_image_dd "$1" of="/tmp/image.bs" count=1 bs=512b 2>/dev/null
	##########################echo "newgetimagedd image.bs check_image()"
	#################v "Extract boot sector from the image > /tmp/image.bs count=1 bs=512b"
	#v "Extract boot sector from the image" #get_imageprints_similar
	##############################################################################
	get_image_dd "$1" of="/tmp/image.bs" count=1 bs=512b
	get_partitions /tmp/image.bs image
	############################################################################compare tables
	diff="$(grep -F -x -v -f /tmp/partmap.bootdisk /tmp/partmap.image)"
	#DBG?> v "$diff?"


	#######################IMPORTANTORIGINAL-REENABLEANDREMOVELOWERSECTIONSONNONDBG
	#######################IMPORTANTORIGINAL-REENABLEANDREMOVELOWERSECTIONSONNONDBG
	#######################IMPORTANTORIGINAL-REENABLEANDREMOVELOWERSECTIONSONNONDBG

	#rm -f /tmp/image.bs /tmp/partmap.bootdisk /tmp/partmap.image

	#######################IMPORTANTORIGINAL-REENABLEANDREMOVELOWERSECTIONSONNONDBG
	#######################IMPORTANTORIGINAL-REENABLEANDREMOVELOWERSECTIONSONNONDBG
	#######################IMPORTANTORIGINAL-REENABLEANDREMOVELOWERSECTIONSONNONDBG

	if [ -n "$diff" ]; then
		#ROOTFSEXPAND=1 next upgrade triggers this skips two part write and resize logic
		#this is just notify... find n diff in write section
		#echo "Partition layout has changed. Full image will be written."
		
		
		#THECOMMONONEifENLARGED
		################v "/tmp/image.bs:$(cat /tmp/image.bs)"
		##############tmp/partmap.bootdisk:$(cat /tmp/partmap.bootdisk)"#tmp/partmap.image:$(cat /tmp/partmap.image)"
		###v " disk:$(cat /tmp/partmap.bootdisk | sed ':a;N;$!ba;s/\n/ /g')"
		###v "image:$(cat /tmp/partmap.image | sed ':a;N;$!ba;s/\n/ /g')"
		v " disk:$(cat /tmp/partmap.bootdisk | sed 's|^|>|g' | sed ':a;N;$!ba;s/\n/ /g')"
		v "image:$(cat /tmp/partmap.image | sed 's|^|>|g' | sed ':a;N;$!ba;s/\n/ /g')"



		rm -f /tmp/image.bs /tmp/partmap.bootdisk /tmp/partmap.image


		v "Layout changed writing full image... "
		ask_bool 0 "Abort" && exit 1
		return 0
	



	else ####################################################HACKFORSHOW-REMOVE
		rm -f /tmp/image.bs /tmp/partmap.bootdisk /tmp/partmap.image
	####################################################################-REMOVE


	fi

	return 0;
}

















checkrootfsresize() {





#@if [ -z "${diskdev}" ]; then
#@if [ -z "$WRITEUUID" ]; then


if [ ! -f /tmp/.upgradeopts ]; then
	NORESIZE="${NORESIZE} no:/tmp/.upgradeopts"
else
	
	
	#@@@multiopts SET resizeMETHOD="expand" or fulldisk
	
	
	eval $(grep 'rootfsexpand=' /tmp/.upgradeopts 2>/dev/null)
	if [ -z "$rootfsexpand" ]; then
		NORESIZE="${NORESIZE} rootfsexpand[off]"
	fi






	eval $(grep 'rootfsdatapart=' /tmp/.upgradeopts 2>/dev/null)
	if [ -z "$rootfsexpand" ] && [ ! -z "$rootfsdatapart" ]; then
		#DBGONLY[present]handles v "rootfsdatapart [detected]"
		ADD_A_DATAPART=1

		##### NORESIZE="${NORESIZE} rootfsdatapart[off]"
		########################@@@multiopts SET resizeMETHOD="expand" or fulldisk
	fi





	

fi #echo "rootfsexpand=1" >> /tmp/.upgradeopts







#@!>weshouldcheckthesealsopreupgradeIFexpandoptset
#@2022datapart fsck.ext4 tune2fsnotusedmaybesinglechecksinthatfunction
reqCMDs="parted resize2fs blkid e2fsck tail"
for cCMD in $reqCMDs; do
	if [ -z "$(command -v $cCMD)" ]; then NOCMD="${NOCMD} $cCMD"; fi
done
if [ ! -z "$NOCMD" ]; then NORESIZE="${NORESIZE} nocmd:$NOCMD"; fi













diskdevPTCNT=$(blkid  | grep "^/dev/${diskdev}" | wc -l)





if [ "$diskdevPTCNT" -ne "2" ]; then


	#@20220203hackforDATAPART #!noTR! ###################################
	PARTCOUNTNOTTWO="${diskdevPTCNT} $(blkid | grep "^/dev/${diskdev}" | cut -d':' -f1 | sed 's|^| |g' | sed ':a;N;$!ba;s/\n/ /g' | sed 's|  | |g')"
	#####################################################################





	#echo "cnt:$diskdev(${diskdevPTCNT})[nomatch]"
	NORESIZE="${NORESIZE} cnt:$diskdev(${diskdevPTCNT})[nomatch]"
else
	#echo "cnt:$diskdev(${diskdevPTCNT})[match]"
	RESIZEOK="${RESIZEOK} cnt:$diskdev(${diskdevPTCNT})"
fi






#@!movedupfrombelowsectionasneededinit_cangohigher?
case "${diskdev}" in
	*mmcblk*)
		DEVp="p"
	;;
	*)
		:
	;;
esac

diskdevR="${diskdev}${DEVp}2" #echo "rootfs:${diskdevR}[diskdevR]"







if ! blkid  | grep "^/dev/${diskdev}${DEVp}2:" | grep -q 'LABEL="rootfs"'; then
	#echo "LABEL=rootfs[nomatch]"
	NORESIZE="${NORESIZE} LABEL=rootfs[nomatch]"
else
	#echo "LABEL=rootfs[match]"
	RESIZEOK="${RESIZEOK} LABEL=rootfs"
fi
#############################diskdevR="${diskdev}${DEVp}2" #rootfsSZ=$(cat /sys/block/${diskdev}/${diskdevR}/size)
###if ! blkid  | grep "^/dev/${diskdev}${DEVp}2:" | grep -q 'LABEL="rootfs"'; then
#v "BBBblkid  | grep "^/dev/${diskdev}${DEVp}2" | grep -q 'LABEL=\"rootfs\"'"
#v "AAA$(blkid  | grep "^/dev/${diskdev}${DEVp}2")"
###FAULTYtail if ! blkid  | grep "^/dev/${diskdev}" | tail -n1 | grep -q 'LABEL="rootfs"'; then
#v "AAAblkid  | grep "^/dev/${diskdev}:" | tail -n1 | grep -q 'LABEL=\"rootfs\"'"
#v "AAA$(blkid  | grep "^/dev/${diskdev}" | tail -n1)"
##########addacolon for sda11 if ! blkid  | grep "^/dev/${diskdev}${DEVp}2" | grep -q 'LABEL="rootfs"'; then








rootfsSZ=$(cat /sys/block/${diskdev}/${diskdevR}/size)
if [ "$rootfsSZ" -ne "1966080" ]; then
	#echo "Rsz:${rootfsSZ}[nomatch]" ##############NORESIZE="${NORESIZE} Rsz:${rootfsSZ}[nomatch]"
	NORESIZE="${NORESIZE} sz:${rootfsSZ}[nomatch]"
else
	#echo "Rsz:${rootfsSZ}[match]" ############RESIZEOK="${RESIZEOK} Rsz:${rootfsSZ}[match]"
	RESIZEOK="${RESIZEOK} sz:${rootfsSZ}"
fi













#[ -z "$ADD_A_DATAPART" ] then echo
if [ ! -z "$NORESIZE" ]; then
	if [ -z "$ADD_A_DATAPART" ]; then
		#hackywrapperabove
		v "ROOTFSEXPAND:${diskdevR} noresize:$NORESIZE [ok:$RESIZEOK]"
	fi
	## v "rootfs:${diskdevR} noresize: $NORESIZE [ok:$RESIZEOK]"
	### echo "rootfs:${diskdevR} noresize: $NORESIZE [ok:$RESIZEOK]"
	############@@@possiblyfrom forcedTESTING UPGRADE_OPT_SAVE_PARTITIONS=1 #@@@ bug if we dont resize
	setPTUUID /dev/${diskdev} "$WRITEUUID"
else
	v "ROOTFSEXPAND:${diskdevR} resize:100%${RESIZEOK}"
	###v "ROOTFSEXPAND:${diskdevR} resize:$RESIZEOK" ####### v "ROOTFSEXPAND rootfs:${diskdevR} resize:$RESIZEOK"
	#@@@ismounted #isrpi4alreadycheckedhere



	#@20220203hackforDATAPART ###################################
	ROOTFSEXPANDED=1
	#############################################################
	
	dorootfsresize || true
	#@??? rootfsSZpost=$(cat /sys/block/${diskdev}/${diskdevR}/size)


fi #sleep 2 #exit 0










if [ ! -z "$ADD_A_DATAPART" ] && [ ! -z "$PARTCOUNTNOTTWO" ]; then




	############################# v "blkidgrep: $(blkid | grep "${diskdev}${DEVp}3:")"
	case  "$(blkid | grep "${diskdev}${DEVp}3:")" in
		*'LABEL="z"'*)
			: ###DBG v "$(blkid | grep "${diskdev}${DEVp}3:") labelok"
			DATAPARTlabelmatch=1
		;;
		*)
			: #DBGtooORsetVAR DATAPARTissues="${DATAPARTissues} badlabel"
			###v "$(blkid | grep "${diskdev}${DEVp}3:") has no or alt_label"
			DATAPARTissues="${DATAPARTissues} badlabel"
		;;
	esac

	if ! partx -v -s -o type /dev/${diskdev}${DEVp}3 | grep -q '83'; then
			DATAPARTissues="${DATAPARTissues} notext4"
	fi





	#NOTE no LABEL VALIDATION will fsck any partiton 3
	FSCKEXT4=$(command -v fsck.ext4 2>/dev/null) 
	if [ ! -z "$DATApartissues" ]; then
		v "fsck [${DATAPARTissues}]"
	elif partx -v -s -o type /dev/${diskdev}${DEVp}3 | grep -q '83'; then
		if [ -z "$FSCKEXT4" ]; then
			#fsck.ext4 not available
			#v "fsck.ext4 not available"
			FSCKinfo="fsck.ext4 [nobin]"
        elif $FSCKEXT4 -n /dev/${diskdev}${DEVp}3 1>/dev/null 2>/dev/null; then
            ###################noneedtofsckrepair
			#v "/dev/${diskdev}${DEVp}3 [fsck-unneeded]"
			#FSCKinfo="/dev/${diskdev}${DEVp}3 [fsck-unneeded]"
			FSCKinfo="${diskdev}${DEVp}3 [fsck-unneeded]"
		else
        	if $FSCKEXT4 -y -f /dev/${diskdev}${DEVp}3 1>/dev/null 2>/dev/null; then
				######################fsckedandworked
				##########3v "/dev/${diskdev}${DEVp}3 [fsck-needed-and-ok]"
				#FSCKinfo="/dev/${diskdev}${DEVp}3 [fsck-needed-and-ok]"
				FSCKinfo="${diskdev}${DEVp}3 [fsck-repaired]"
			else
				#fsckedandfailed
				## v "#! /dev/${diskdev}${DEVp}3 [fsck-failed]"
				#FSCKinfo="#! /dev/${diskdev}${DEVp}3 [fsck-failed]"
				FSCKinfo="#!${diskdev}${DEVp}3 [fsck-failed]"
				### MODDEDCUSTOMnewCOMMON.SH for all v #vRPT "/dev/${diskdev}${DEVp}3 [fsck-failed]"
				### #echo "#!test text" >> /tmp/.upgrade.rpt
			fi
		fi
	else
		###########################isnotext4
		#v "/dev/${diskdev}${DEVp}3 [not-ext4]"
		#FSCKinfo="/dev/${diskdev}${DEVp}3 [not-ext4]"
		FSCKinfo="${diskdev}${DEVp}3 [not-ext4]"
	fi











	if [ -z "$DATAPARTissues" ]; then
		v "ROOTFSEXPAND_DATAPART [present] p:$diskdevPTCNT $FSCKinfo"
	else
		########v "adddatapart [morethantwoparts:$(echo ${PARTCOUNTNOTTWO} | sed 's|/dev/||g')] $FSCKinfo"
		v "ROOTFSEXPAND_DATAPART [morethantwo:$(echo ${PARTCOUNTNOTTWO} | sed 's|/dev/||g')] $FSCKinfo"
		#NOTE: rm after testing 0p3 on LIVE os WITHOUT partprobe? triggered this!!!
		#or bad logic does not sound right
	fi








elif [ ! -z "$ADD_A_DATAPART" ] && [ ! -z "$ROOTFSEXPANDED" ]; then
	v "ROOTFSEXPAND_DATAPART [rootfswasexpanded]"
elif [ ! -z "$ADD_A_DATAPART" ] && [ -z "$PARTCOUNTNOTTWO" ] && [ -z "$ROOTFSEXPANDED" ]; then
	v "ROOTFSEXPAND_DATAPART [adding data partition]"
	dodatapart || true
fi




}






setPTUUID() {
	local inDSK="${1}"
	local PTUUID="${2}"
	if [ "$(getPTUUID "${inDSK}")" = "$PTUUID" ]; then
		v "$PTUUID [ptuuid-ok]" ### echo "$PTUUID [ptuuid-ok]"
	else
		v "$PTUUID [ptuuid-write]" ### echo "$PTUUID [ptuuid-write]"
		(echo p; echo x; echo i; echo 0x${PTUUID}; echo r; echo w) | fdisk "${inDSK}" >/dev/null
	fi
}


getPTUUID() {
	local inDSK="${1}"
	blkid "$inDSK" -s PTUUID -o value
} #blkid /dev/sdc -s PTUUID -o value




















dorootfsresize() {


	#local RESIZEdbg=1
	

	if [ -n "$RESIZEdbg" ]; then
		v "parted /dev/${diskdev} resizepart 2 100%" ######## echo "parted /dev/${diskdev} resizepart 2 100%"
		parted /dev/${diskdev} resizepart 2 100%
	else	
		#MOVING THIS UP TO CALLING RPT FOR A WHILE v "resizing rootfs 100%" ################echo "resizing rootfs 100%"
		parted /dev/${diskdev} resizepart 2 100% 1>/dev/null 2>/dev/null
	fi




	[ -n "$RESIZEdbg" ] && getPTUUID /dev/${diskdev}
	setPTUUID /dev/${diskdev} "$WRITEUUID"
	[ -n "$RESIZEdbg" ] && getPTUUID /dev/${diskdev}



	###############################@@@missing e2fsck here or after 100%
	#v "resize2fs /dev/${diskdevR}" ########## echo "resize2fs /dev/${diskdevR}"
	if [ -n "$RESIZEdbg" ]; then
		v "resize2fs /dev/${diskdevR}" ########## echo "resize2fs /dev/${diskdevR}"
		resize2fs /dev/${diskdevR}
	else
		resize2fs /dev/${diskdevR} 1>/dev/null 2>/dev/null
	fi
	#[ -n "$RESIZEdbg" ] && getPTUUID /dev/${diskdev}

	#@??? rootfsSZpost=$(cat /sys/block/${diskdev}/${diskdevR}/size)


	[ -n "$RESIZEdbg" ] && echo "sync" #@>v?
	sync


}









dodatapart() {



	local RESIZEdbg=1

	if [ -n "$RESIZEdbg" ]; then

	
		
		
		#@> v "verbose mode"

		if blkid | grep "^/dev/${diskdev}${DEVp}3" | grep FSTYPE; then
				v "/dev/${diskdev}${DEVp}3 already has a filesystem"
				return 0
		fi




		#AFTER v "parted /dev/${diskdev} mkpart primary ext4 1450MiB 100%"
		parted /dev/${diskdev} mkpart primary ext4 1450MiB 100%
		PARTED_RET=$?
		v "parted /dev/${diskdev} mkpart primary ext4 1450MiB 100% [$PARTED_RET]"
		sleep 2 #REMOVETHISTEST? ##parted -s? ### v "parted ret:$PARTED_RET"
		##>glithc? v "blkid1: $(blkid | grep "^/dev/${diskdev}" | cut -d':' -f1 | sed 's|^|>|g' | sed ':a;N;$!ba;s/\n/ /g')"
		#######adjustbackdowntoseeiffixes-persistentlabel from tune2fs





		setPTUUID /dev/${diskdev} "$WRITEUUID"







		###########################? messing up partprobe/kpartx? 			setPTUUID /dev/${diskdev} "$WRITEUUID"
		#v "doatestuuidfixupbeforemkfs"
		#UMTHISisBAD? setPTUUID /dev/${diskdev} "$WRITEUUID"






		######################20220205 HMMM 80_mount_root just has dev partx -u - /dev/${diskdev}
		############# partx -u 3 /dev/${diskdev} #partx -u /dev/${diskdev} #partx -a 3 /dev/${diskdev}
		#partx -u 3 /dev/${diskdev} ### partx -u /dev/${diskdev} ### or - u above is size change?		
		v "probing new partion..."
		partx -u /dev/${diskdev}
		sleep 2
		#v "DBG blkid2: $(blkid | grep "^/dev/${diskdev}" | cut -d':' -f1 | sed 's|^|>|g' | sed ':a;N;$!ba;s/\n/ /g')"
		######################sleep 2 #!1?LEAVEATTWOUNLESSTESTINGALONEMOVEDUPBEFOREPRINT






		### v "mount: $(mount)"





		#if [ ! -z "$(command -v partprobe)" ]; then
		#	v "partprobe: $(partprobe)" #v "blkid3: $(blkid | grep "^/dev/${diskdev}" | cut -d':' -f1)"		
		#	######v "blkid3: $(blkid | grep "^/dev/${diskdev}" | cut -d':' -f1 | sed 's|^|>|g' | sed ':a;N;$!ba;s/\n/ /g')"
		#else
		#	v "partprobe: [nope]"
		#fi
		#sleep 2 #?1
		#v "blkid5: $(blkid | grep "^/dev/${diskdev}" | cut -d':' -f1 | sed 's|^|>|g' | sed ':a;N;$!ba;s/\n/ /g')"
		##################v "blkid5: $(blkid | grep "^/dev/${diskdev}" | cut -d':' -f1)"



		############################NOPE sortof TESTTHISBEFOREMKFS FORCING p3 to SHOW UP
		##########################setPTUUID /dev/${diskdev} "$WRITEUUID"
		###############################sleep 2



		#####echo 1 > /sys/block/${diskdev}/device/rescan; sleep 2 #!1?LEAVEATTWOUNLESSTESTINGALONE
		#####v "blkid7: $(blkid | grep "^/dev/${diskdev}" | cut -d':' -f1 | sed 's|^|>|g' | sed ':a;N;$!ba;s/\n/ /g')"



		if [ "${PARTED_RET:-"1"}" -eq 0 ]; then
		

			############ NOTE: this does not work and relies on hotplug 56 3rd part with not fs on rootdev
			############       actually if latent fs is there may work(well blockdev may show up)
			#v "$(mkfs.ext4 -F -L z /dev/${diskdev}${DEVp}3)"
			#v "mkfs.ext4 -F -L z /dev/${diskdev}${DEVp}3"
			###FAULTY? v "mkfs.ext4 ret:$?"



			################################################################# TESTINGSECTION
			if [ ! -b /dev/${diskdev}${DEVp}3 ]; then
				#v "DBGdbg-noblockdev: /dev/${diskdev}${DEVp}3 [doitanyway]"
				:
			
			
			
			
			
				#setPTUUID /dev/${diskdev} "$WRITEUUID"
				#if [ ! -b /dev/${diskdev}${DEVp}3 ]; then
				#	v "dbg-still-noblockdev1: /dev/${diskdev}${DEVp}3 [setPTUUID]"
				#fi
				
				
				#partprobe
				#if [ ! -b /dev/${diskdev}${DEVp}3 ]; then
				#	v "dbg-still-noblockdev1: /dev/${diskdev}${DEVp}3 [partprobe]"
				#fi
				

				#partx -u /dev/${diskdev}
				#if [ ! -b /dev/${diskdev}${DEVp}3 ]; then
				#	v "dbg-still-noblockdev1: /dev/${diskdev}${DEVp}3 [partx -u /dev/${diskdev}]"
				#fi














				#v "probing new partion..."
				#partx -u /dev/${diskdev}
			
			fi #/dev/${diskdev}${DEVp}3
			################################################################# TESTINGSECTION













			if [ -b /dev/${diskdev}${DEVp}3 ]; then

				v "mkfs.ext4 -F -L z /dev/${diskdev}${DEVp}3"
				mkfs.ext4 -F -L z /dev/${diskdev}${DEVp}3 1>/dev/null
				MKFS_RET=$?
				#mkfs.ext4 -F -L z /dev/${diskdev}${DEVp}3
				#v "DBG mkfs.ext4 -F -L z /dev/${diskdev}${DEVp}3 [$MKFS_RET]"







				nUUID="23232323-2323-2323-2323-232323232323"
				if ! blkid /dev/${diskdev}${DEVp}3 | grep -q "$nUUID"; then
					v "tune2fs -U $nUUID /dev/${diskdev}${DEVp}3" ####################### 5seconds!
					tune2fs -U $nUUID /dev/${diskdev}${DEVp}3 1>/dev/null

				fi
				##############################################################################################
				#@also needs rechecking aka partition was not blanked? AKA ifisdifferent
				#@command -v check
				##############################################################################################
				#This operation requires a freshly checked filesystem Please run e2fsck -f on the filesystem
				#e2fsck -f /dev/sdb3
				#v "tune2fs -l /dev/${diskdev}${DEVp}3 | grep Last\ c"
				#v "$(tune2fs -l /dev/${diskdev}${DEVp}3 | grep Last\ c)"
				##############################################################################################





			else
				
				v "/dev/${diskdev}${DEVp}3 [noblock:initialize-on-boot]"
				#v "mkfs.ext4 -F -L z /dev/${diskdev}${DEVp}3 [noblock]"

			fi












		else
			v "mkfs.ext4 nope parted had issues"	
		fi







	else	

		v "silent mode"
		#1>/dev/null 2>/dev/null
		:
	

	fi








	[ -n "$RESIZEdbg" ] && getPTUUID /dev/${diskdev}
	setPTUUID /dev/${diskdev} "$WRITEUUID"
	[ -n "$RESIZEdbg" ] && getPTUUID /dev/${diskdev}


	[ -n "$RESIZEdbg" ] && echo "sync"
	sync


}



		



######## echo "y" | mkfs.ext4 -F -L z /dev/${diskdev}${DEVp}3
#echo 1 > /sys/block/sdc/device/rescan
########################################################e2fsck? i’ve solve my problem with
#sudo partx -u /dev/sda (as -a reported some errors)
#sudo resize2fs /dev/sda1



#########################################################################################################
	##############################################	
	#if [ -z "$(command -v tune2fs)" ]; then
	#	v "tune2fs nope"
	#else
	#	v "tune2fs $(command -v tune2fs)"
	#fi
#########################################################################################################
		#carefull with this may have done something persistent aka openwrt keeps picking up old labels
		#tune2fs -U 2037add3-3231-1232-2312-11ce10000023 /dev/mmcblk0p3
#########################################################################################################

		#mke2fs -t ext4 -L z /dev/${diskdev}${DEVp}3
		################################################################################# NOTE false POSITIVE
		#The file /dev/mmcblk0p3 does not exist and no size was specified.
		#The file /dev/mmcblk0p3 does not exist and no size was specified.
		#The file /dev/mmcblk0p3 does not exist and no size was specified.



#########################################################################################################
######### TR_NO! v "blkid1: $(blkid | grep "^/dev/${diskdev}" | cut -d':' -f1 | tr -s '\n' ' ')"
#########################################################################################################
##############################################################################NOPE
#v "mke2fs -t ext4 -L z /dev/${diskdev}${DEVp}3" #mkfs -t ext4 -L rootfs /dev/sda1
#OK @ v "mke2fs $(command -v mke2fs)" ###Fri Feb  4 06:57:36 UTC 2022 upgrade: mke2fs /usr/sbin/mke2fs
#NOPE v "mkfs $(command -v mkfs)" ### Fri Feb  4 06:57:36 UTC 2022 upgrade: mkfs 
#########################################################################################################
#########################################################################################################
#parted /dev/${diskdev}mkpart "store" ext4 415MiB 100% ################407MB
























































platform_do_upgrade() {








	if [ -f /tmp/.upgradeopts ]; then
		eval $(grep 'TZ=' /tmp/.upgradeopts 2>/dev/null)
		if [ ! -z "$TZ" ]; then
			export TZ="$TZ"
		fi
	fi #export TZ='AEST-10AEDT,M10.1.0,M4.1.0/3'


	if [ -f /tmp/.upgradeopts ]; then
		eval $(grep 'UPGRADEt_BEGIN=' /tmp/.upgradeopts 2>/dev/null)
	fi


	if [ -f /tmp/.upgradeopts ]; then
		eval $(grep 'SYNCDRIVE_SLAVE=' /tmp/.upgradeopts 2>/dev/null)
	fi

	#@@aftergetbootdevice
	if [ ! -z "${SYNCDRIVE_SLAVE}" ]; then
		sync_a_drive
	fi
	#v "SYNCDRIVE_SLAVE=${SYNCDRIVE_SLAVE} [off]"




	local diskdev partdev diff

	export_bootdevice && export_partdevice diskdev 0 || {
		echo "Unable to determine upgrade device"
		return 1
	}

	sync



	#20210717 NOTE THIS DOES NOT REALLY WORK SO COPIED UP THE RESIZE CHECK AFTER WRITE
	#FORCETHISONHERE to see what happens with resize as diff=1 aka we resized prev install
	#at platform_check_image print at sysupgrade means this is a straight write
	#alternative is
	#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	# UPGRADE_OPT_SAVE_PARTITIONS=1 #forcesthisonforabitUNEEDED
	#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

	if [ "$UPGRADE_OPT_SAVE_PARTITIONS" = "1" ]; then
		get_partitions "/dev/$diskdev" bootdisk


		#get_image "$@" | dd of=/tmp/image.bs count=1 bs=512b
		############################################GETIMAGE 2>/dev/null?
		#DBG v "Extract boot sector from image (compare with $diskdev)"
		get_image_dd "$1" of="/tmp/image.bs" count=1 bs=512b

		get_partitions /tmp/image.bs image

		#compare tables
		diff="$(grep -F -x -v -f /tmp/partmap.bootdisk /tmp/partmap.image)"
		


		#20210717 MEHDBGONLY
		#[ -n "$diff" ] && echo "image and disk parts differ: $diff" && sleep 2


	else
		diff=1
	fi




	if [ -n "$diff" ]; then #nb always a diff unless in image is exact as prevparts

		####################################################################3#DBGONLY
		#v "disk:$(cat /tmp/partmap.bootdisk)" ###NOtr? v "disk:$(cat /tmp/partmap.bootdisk | tr -s '\n' ' ')"
		#v "image:$(cat /tmp/partmap.image)"   ###      v "/tmp/partmap.bootdisk:$(cat /tmp/partmap.bootdisk)"


		OLDUUID=$(partx -g -o UUID "/dev/$diskdev" 2>/dev/null | dd bs=1 count=8 2>/dev/null)	
	

		#ORIGINAL get_image "$@" | dd of="/dev/$diskdev" bs=2M conv=fsync
		v "Writing full-image to $diskdev" #v "Writing full-image to $diskdev [<${1}]"
		get_image_dd "$1" of="/dev/$diskdev" bs=2M conv=fsync

        # Separate removal and addtion is necessary; otherwise, partition 1
		# will be missing if it overlaps with the old partition 2
		partx -d - "/dev/$diskdev"
		partx -a - "/dev/$diskdev"





		######### TOOLATE OLDUUID=$(partx -g -o UUID "/dev/$diskdev" 2>/dev/null | dd bs=1 count=8 2>/dev/null)
    	WRITEUUID="$OLDUUID"
		checkrootfsresize || true








	#NEEDStoMOVEtoCOPYniceENDtwoOFTHESEdependingONFULLwrite
	if [ ! -z "$UPGRADEt_BEGIN" ]; then
		UPGRADEt_WRITEDONE="`sed 's/[. ].*//' /proc/uptime`"
		########## v "UPGRADE_ELAPSED_WRITE: $(($UPGRADEt_WRITEDONE - $UPGRADEt_BEGIN))seconds"
		echo "UPGRADEt_WRITEDONE=\"${UPGRADEt_WRITEDONE}\"" >> /tmp/.upgradeopts
	

	
		###############################################justforthisecho	
		UPt_EWs="$(($UPGRADEt_WRITEDONE - $UPGRADEt_BEGIN))"
		UPt_EWm="$(($UPt_EWs / 60))"
		v "UPGRADE_ELAPSED_WRITE: ${UPt_EWm}mins (${UPt_EWs}secs)"
	fi
	###echo "UPGRADEt_BEGIN=\"`sed 's/[. ].*//' /proc/uptime`\"" >> /tmp/.upgradeopts









	#v "tune2fs -l "/dev/${diskdev}${DEVp}2" | grep \"Last checked\""
	#v "$(tune2fs -l "/dev/${diskdev}${DEVp}2" | grep "Last checked")"		
#########################################################################################
#Sat Feb 12 19:49:53 AEDT 2022 tune2fs -l /dev/sdb2 | grep "Last checked"
#Sat Feb 12 19:49:53 AEDT 2022 Last checked:             Thu Jan  1 11:00:00 1970
#Sat Feb 12 19:49:53 AEDT 2022 tune2fs -T now /dev/sdb2
#Sat Feb 12 19:49:53 AEDT 2022 tune2fs 1.46.5 (30-Dec-2021)
#Setting time filesystem last checked to Sat Feb 12 19:49:53 2022
#Sat Feb 12 19:49:53 AEDT 2022 tune2fs -c 1 /dev/sdb2 | grep Last\ c
#Sat Feb 12 19:49:53 AEDT 2022 Last checked:             Sat Feb 12 19:49:53 2022
#Sat Feb 12 19:49:53 AEDT 2022 copy_overlay: [none]
#######################################################################################






	tune2fs -T now /dev/${diskdev}${DEVp}2 1>/dev/null
	#v "tune2fs -T now /dev/${diskdev}${DEVp}2"
	#v "out: $(tune2fs -T now /dev/${diskdev}${DEVp}2)"
	#v "noout: $(tune2fs -T now /dev/${diskdev}${DEVp}2 1>/dev/null)"
	###### OKv "tune2fs -c 1 /dev/${diskdev}${DEVp}2 | grep Last\ c"; "$(tune2fs -l /dev/${diskdev}${DEVp}2 | grep Last\ c)"

	tune2fs -c 23 /dev/${diskdev}${DEVp}2 1>/dev/null
	#v "tune2fs -c 23 /dev/${diskdev}${DEVp}2"; v "$(tune2fs -c 23 /dev/${diskdev}${DEVp}2)"
	######### #v "tune2fs -c 1 /dev/${diskdev}${DEVp}2"; v "$(tune2fs -c 1 /dev/${diskdev}${DEVp}2)"









		return 0
	fi







    #NOTE didntprint console thing???
    #local DEBUGDISKWRITE=1
    #if [ ! -z "$DEBUGDISKWRITE" ]; then
	#    while read part start size; do
	#	    	echo "DBG Writing image to /dev/$partdev... partition:$part start:$start size:$size"
    #    done < /tmp/partmap.image
    #fi




	#v "disk and image partions match"
	#v "disk:$(cat /tmp/partmap.bootdisk)" ##########3v "/tmp/partmap.bootdisk:$(cat /tmp/partmap.bootdisk)"
	#v "image:$(cat /tmp/partmap.image)" ##########v "/tmp/partmap.image:$(cat /tmp/partmap.image)"





	##########################iterate over each partition from the image and write it to the boot disk
	while read part start size; do
		#echo "partition:$part start:$start size:$size"
		if export_partdevice partdev $part; then

			#########################ORIGINAL echo "Writing image to /dev/$partdev..."
			#20220203 upgraderptecho "Writing image-partition:$part to /dev/$partdev... start:$start size:$size"
			v "Writing image-partition:$part to /dev/$partdev... start:$start size:$size"
			
			
			
			###########################20210717 NEWFORLOWERRESIZE #>>>notusedGETfromsysblock
			### if [ "$part" -eq 2 ]; then ROOTFSinSZ="$size"; fi



		#get_image "$@" 2>/dev/null | dd of="/dev/$partdev" ibs="512" obs=1M skip="$start" count="$size" conv=fsync
		get_image_dd "$1" of="/dev/$partdev" ibs="512" obs=1M skip="$start" count="$size" conv=fsync



        else
			#ORIGINAL echo "Unable to find partition $part device, skipped."
			echo "Unable to find partition $part device, skipped."
	fi
	done < /tmp/partmap.image




	##########################################################################################
	#ORIGINALISWRONG ######################get_image "$@" | dd of="/tmp/faketable" bs=2M conv=fsync 2>/dev/null
	######################################disk is full aka 512b count 1
	###########################get_image "$@" | dd of="/tmp/faketable" bs=512b count=1 2>/dev/null
    ############################v "TEST: $(partx -g -o UUID "$1" | dd bs=1 count=8 2>/dev/null)"
	##########################################################################################
	get_image_dd "$1" of="/tmp/faketable" bs=512b count=1

    NEWUUID=$(partx -g -o UUID "/tmp/faketable" | dd bs=1 count=8 2>/dev/null)
    OLDUUID=$(partx -g -o UUID "/dev/$diskdev" 2>/dev/null | dd bs=1 count=8 2>/dev/null)
	#######################################@@@VALIDATE[0-9][a-z]&&||charnum
	############################################NOTUSED
    OLDUUIDASCII=$(dd if=/dev/$diskdev bs=1 skip=440 count=4 2>/dev/null)
    NEWUUIDASCII=$(dd if=/tmp/faketable bs=1 skip=440 count=4 2>/dev/null)
    #ASCIIUGLY echo "Writep PARTUUID[${OLDUUID}:(${OLDUUIDASCII})] /dev/$diskdev... IMG[${NEWUUID}:(${NEWUUIDASCII})]"

	###20220203 upgraderpt echo "Writing previous PARTUUID[${OLDUUID}] to /dev/$diskdev... IMG[${NEWUUID}]"
	v "Writing previous PARTUUID[${OLDUUID}] to /dev/$diskdev... IMG[${NEWUUID}]"
    dd if=/tmp/faketable bs=1 skip=440 count=4 2>/dev/null | dd of="/dev/$diskdev" bs=1 skip=440 count=4 seek=440 conv=fsync 2>/dev/null


    WRITEUUID="$OLDUUID"
	checkrootfsresize || true
	
	
	





	
	if [ ! -z "$UPGRADEt_BEGIN" ]; then
		UPGRADEt_WRITEDONE="`sed 's/[. ].*//' /proc/uptime`"

		#v "writetimesecs: $(($UPGRADEt_WRITEDONE - $UPGRADEt_BEGIN))"
		UPt_EWs="$(($UPGRADEt_WRITEDONE - $UPGRADEt_BEGIN))"
		UPt_EWm="$(($UPt_EWs / 60))"
		v "UPGRADE_ELAPSED_WRITE: ${UPt_EWm}mins (${UPt_EWs}secs)"
		
		
		echo "UPGRADEt_WRITEDONE=\"${UPGRADEt_WRITEDONE}\"" >> /tmp/.upgradeopts
	fi
	###echo "UPGRADEt_BEGIN=\"`sed 's/[. ].*//' /proc/uptime`\"" >> /tmp/.upgradeopts


	
	





	#v "tune2fs -l "/dev/${diskdev}${DEVp}2" | grep \"Last checked\""
	#v "$(tune2fs -l "/dev/${diskdev}${DEVp}2" | grep "Last checked")"




	tune2fs -T now /dev/${diskdev}${DEVp}2 1>/dev/null
	#v "tune2fs -T now /dev/${diskdev}${DEVp}2"
	#v "out: $(tune2fs -T now /dev/${diskdev}${DEVp}2)"
	#v "noout: $(tune2fs -T now /dev/${diskdev}${DEVp}2 1>/dev/null)"
	###### OKv "tune2fs -c 1 /dev/${diskdev}${DEVp}2 | grep Last\ c"; "$(tune2fs -l /dev/${diskdev}${DEVp}2 | grep Last\ c)"

	tune2fs -c 23 /dev/${diskdev}${DEVp}2 1>/dev/null
	#v "tune2fs -c 23 /dev/${diskdev}${DEVp}2"; v "$(tune2fs -c 23 /dev/${diskdev}${DEVp}2)"
	######### #v "tune2fs -c 1 /dev/${diskdev}${DEVp}2"; v "$(tune2fs -c 1 /dev/${diskdev}${DEVp}2)"


















	
	
	
	#NOTEthisisinthewrongishSPOTakaNOTthemainoneMANUALLYadded?akaFULLWRITEdoesnotgethere20220211

	if [ -f /tmp/restore.tar.gz ]; then
		#v "Copying alternate backup: $(find /tmp/res*.tar.gz -type f | grep '.tar.gz$' | tail -n1)"
		
		
		#v "Copying alternate backup: /tmp/restore.tar.gz /boot/"
		if ! mount -t vfat /dev/${diskdev}${DEVp}1 /boot; then
			v "#!backup-override: /tmp/restore.tar.gz /boot/ [Unable to mount]"
		else
			v "backup-override: /tmp/restore.tar.gz /boot/sysupgrade.tgz"
			cp /tmp/restore.tar.gz /boot/sysupgrade.tgz
			sync
			umount -l /boot
		fi

	else
		: #dbgonly
		## v "backup-override [no]"
		### v "backup-override: find /tmp | grep 'tar.gz$' $(find /tmp | grep '.tar.gz$')"
	fi













	############# moved to platformcopynice

	#if [ -f /tmp/.upgrade.rpt ]; then
	#	v "Copying upgrade report"
	#	if mount -t vfat /dev/${diskdev}${DEVp}1 /boot; then
	#		cp -u /tmp/.upgrade.rpt /boot/
	#		sync
	#	else
	#		v "Unable to mount"
	#	fi
	#	umount -l /boot
	#else 
	#	v "Copying upgrade report [nope]"
	#fi
		#mount -t vfat /dev/${diskdev}${DEVp}1 /boot || v "Unable to mount"
		#cp -u /tmp/.upgrade.rpt /boot/
		#sync
		#umount -l /boot
	###########/lib/upgrade/do_stage2:v "Upgrade completed" #+rpi4 overlaycp platform_copy_config>nice below
	###echo "Upgrade completed" >> /tmp/.upgrade.rpt


}













platform_copy_config() {


	local FN="platform_copy_config"



	if type platform_copy_confignice 2>/dev/null 1>/dev/null; then
        ### echo "$FN> CONSOLE using> platform_copy_confignice include@rpi4.sh" > /dev/console
        echo "$FN> using platform_copy_confignice include@rpi4.sh" > /dev/console
        platform_copy_confignice
		return 0
	fi




	local partdev

	if export_partdevice partdev 1; then

		[ -n "$DEBUG" ] && vplat "$FN> partdev: /dev/$partdev"

		mkdir -p /boot
		[ -f /boot/kernel.img ] || mount -t vfat -o rw,noatime "/dev/$partdev" /boot

		cp -af "$UPGRADE_BACKUP" "/boot/$BACKUP_FILE"

        	echo "$FN> workaround @ true" > /dev/console
        	tar -C / -zxvf "$UPGRADE_BACKUP" boot/cmdline.txt boot/config.txt || true

		sync
		umount /boot
	fi


}















	#local diskdev partdev diff

	#export_bootdevice && export_partdevice diskdev 0 || {
	#	echo "Unable to determine upgrade device"
	#	return 1
	#}
	#sync



	#20210717 NOTE THIS DOES NOT REALLY WORK SO COPIED UP THE RESIZE CHECK AFTER WRITE
#diskdevPTCNT=$(blkid  | grep "^/dev/${diskdev}" | wc -l)








#if [ -z "$(command -v parted)" ]; then NOCMD="${NOCMD} parted"; fi
#if [ -z "$(command -v resize2fs)" ]; then NOCMD="${NOCMD} resize2fs"; fi
#if [ -z "$(command -v blkid)" ]; then NORESIZE="${NORESIZE} blkid"; fi
#if [ -z "$(command -v e2fsck)" ]; then NORESIZE="${NORESIZE} e2fsck"; fi
#if [ -z "$(command -v tail)" ]; then NORESIZE="${NORESIZE} tail"; fi



#Y
#if [ ! -z "$(command -v mkfs.ext4)" ]; then
#	v "mkfs.ext4 [available]"
#else
#	v "mkfs.ext4 [notavailable]"
#fi
#N
#if [ ! -z "$(command -v tr)" ]; then
#	v "tr [available]"
#else
#	v "tr [notavailable]"
#fi
#Y
#if [ ! -z "$(command -v tail)" ]; then
#	v "tail [available]"
#else
#	v "tail [notavailable]"
#fi





#tar -C / -zxvf "$UPGRADE_BACKUP" boot/cmdline.txt boot/config.txt || true

