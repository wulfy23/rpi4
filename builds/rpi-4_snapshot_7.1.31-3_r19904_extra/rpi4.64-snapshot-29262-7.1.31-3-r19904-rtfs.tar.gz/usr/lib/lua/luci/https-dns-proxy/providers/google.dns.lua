return {
	name = "dns.google",
	label = _("Google"),
	resolver_url = "https://dns.google/dns-query",
	bootstrap_dns = "8.8.8.8,8.8.4.4,2001:4860:4860::8888,2001:4860:4860::8844"
}
