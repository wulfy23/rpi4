#!/bin/sh



#@/sbin/poweroff






#set -x







WRAPn="$0"
bNAME="$(basename $0)"

SHUTscr="/etc/custom/shutdown.sh"








#DEBUG=1
[ -n "$DEBUG" ] && RCSLEEP=1










eKO() {
	#[ -n "$DEBUG" ] && echo "$bNAME ${*}"
	#echo "$0 or wrapper PUTHISONFORABITeKO-consoleonly-$bNAME ${*}" > /dev/console
	[ -n "$DEBUG" ] && echo "consoleonly-$bNAME ${*}" > /dev/console
}






























#@@@ case what we were called as...
case "$bNAME" in
    reboot)
        :
    ;;
    halt)
        :
    ;;

    *)
        eKO "OOOOOOOOOOOOOOOOOOOOOOOO: $0 ${*}"; sleep 7
    ;;
esac
#eKO "PAYLOADCMD(early): /bin/busybox ${bNAME} ${@}"; sleep ${RCSLEEP:-0}















if [ "$(pwd)" = "/tmp/root" ]; then #eKO ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>> all done"
    ISTMPFS=1
fi















####################THISFAILSONFSCK@80MOUNTROOTthenREBOOT-checkviacmdline board_name=$(cat /tmp/sysinfo/board_name)
























###@@@+isearlybootTESTecho
if ! mount | grep ' / ' | grep -q rw && [ -z "$ISTMPFS" ]; then
	
	#@202103115_alter@fsck
	#!!! was 7 to stop fsck corruption issue? > waitforfsckprobably
    #! eKO ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>> reboot called at early boot"; sleep 7


	#@~>ISSTARTUP
	while [ ! -z "$(ps w | grep -v grep | grep fsck)" ]; do
		eKO ">>>  waiting for fsck: $(ps w | grep -v grep | grep fsck)"
		sleep 1
	done

	eKO ">>>  fsckfail?"


	#eKO ">>>  reboot called at early boot or rootfsunmounted"; sleep 5
	eKO ">>>  reboot-called-early-boot or rootfsunmounted[$(cat /proc/$$/cmdline)"
	eKO ">>>  reboot-called-early-boot or rootfsunmounted[$(cat /proc/$PPID/cmdline)"

	eKO ">>>  sleep2"
	sleep 2
    
	/bin/busybox ${bNAME} ${@}


fi

























#elif [ -z "$ISTMPFS" ] better spot for touch banner
	:
	####################### @sysfixtime speedups ISNOTMOUNTED>reboot shutdown.sh_top_RO>plog
	#bannerlasttime=$(date -r /etc/banner)
	#touch /etc/banner
	#bannernewtime=$(date -r /etc/banner)
	#echo "$0-$Bname touch /etc/banner [$bannerlasttime > $bannernewtime]" > /dev/console


















#board_name=$(cat /tmp/sysinfo/board_name 2>/dev/null)
#case "$board_name" in *"4-model-b"*) ISRPI4=1; ;; esac #echo "board_name: $board_name ISRPI4=$ISRPI4" > /dev/console
############## hardcodeON
ISRPI4=1












#if [ ! -z "$ISRPI4" ]; then
# probable-triplecheckcmdline.txtHASNOINVALIDPARTUUIDhere due to config restore
#fi






















if [ ! -z "$ISTMPFS" ]; then
    eKO ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>> all done"

#@202105 lower unconditonal backup stuff we can reboot basic now
    /bin/busybox ${bNAME} ${@}
elif [ ! -z "$ISRPI4" ] && [ -f "$SHUTscr" ]; then
    eKO "RUNNING: $SHUTscr plog"; $SHUTscr plog
    eKO "RUNNING: $SHUTscr shutdown"; $SHUTscr shutdown
elif [ ! -z "$ISRPI4" ] && [ ! -f "$SHUTscr" ]; then
    eKO "pre-shutdown: $SHUTscr [missing]"; sleep ${RCSLEEP:-0}; #notDEBUG@eKO #20210129alsonotrpi4
else
    eKO "pre-shutdown: $SHUTscr [leave-nonrpi4-wip-testforpsavevarfallbacks]"; sleep ${RCSLEEP:-0}
    echo "pre-shutdown: $SHUTscr [leave-nonrpi4-wip-testforpsavevarfallbacks]" > /dev/console
fi; sleep ${RCSLEEP:-0}





















#####if [ ! -z"$ISRPI4" ] && [ -f "$SHUTscr" ]; then #if [ -f "$SHUTscr" ]; then #NOTE: wrapthisstuffforRPI4onlybutprintconsoleifnot
######@shutdown.shPLOG||PDIRetcalternativescheck
######maynotwork@elseabove -> dbg find board_name

################### OLDLOGICPREISRPI4
################### OLDLOGICPREISRPI4
################### OLDLOGICPREISRPI4
################### OLDLOGICPREISRPI4
################### OLDLOGICPREISRPI4
################### OLDLOGICPREISRPI4
#####################if [ ! -z "$ISRPI4" ] && [ -f "$SHUTscr" ]; then
#if [ -f "$SHUTscr" ]; then #NOTE: wrapthisstuffforRPI4onlybutprintconsoleifnot
#    eKO "RUNNING: $SHUTscr plog"; $SHUTscr plog
#    eKO "RUNNING: $SHUTscr shutdown"; $SHUTscr shutdown
#else
#    if [ "$(pwd)" = "/tmp/root" ]; then
#        : #called from sysupgrade end
#        eKO ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>> all done"
#    else
#        eKO "pre-shutdown: $SHUTscr [missing]"; sleep ${RCSLEEP:-0}; #notDEBUG@eKO #20210129alsonotrpi4
#    fi
#fi; sleep ${RCSLEEP:-0}











#all need 'non-stop||shutdown' calls or change to early STOP=25 not 90ish || exec busybox?













if [ -x /etc/init.d/persistentdata ]; then
	/etc/init.d/persistentdata savedata 2>/dev/null
fi
########################### NOTE: 2022 K89 IN ADDITION TO ABOVE not SURE IF ABOVE IS WORKING @ halt














if [ -x /etc/init.d/persistentlucistatistics ]; then
/etc/init.d/persistentlucistatistics stop 2>/dev/null #||psave?@202105 procd stop exit 0@busybox late exec corruption
fi


if [ -x /etc/init.d/persistentnlbwmon ]; then
	/etc/init.d/persistentnlbwmon stop 2>/dev/null #||psave?@202105 procd stop exit 0@busybox late exec corruption
fi











allpointlessatbusyboxrealcallsstop() {


while [ ! -z "$(ps w | grep -v grep | grep shutdown.sh)" ]; do
	echo "waiting for shutdown.sh" >/dev/kmsg
	sleep 1
done

while [ ! -z "$(ps w | grep -v grep | grep '/init.d/peristent')" ]; do
	echo "waiting for persisent $(ps w | grep -v grep | grep persistent)" >/dev/kmsg
	sleep 1
done


ps w | grep -v '/bin/bash$' | grep -v grep | grep -v '\]$' | grep -v 'ps w$' | while read FSH; do
	case "$FSH" in
	 *"ash"|*"login"|*"login.sh"|*'/bin/bash$'|*']'|*'ps w')
		continue
	;;
	esac



	#FSHpretty=$(echo $FSH | cut -d' ' -f5-)
	#echo "PS-FSH: $FSHpretty" >/dev/console

	tPID=$(echo $FSH | sed 's!^ !!g' | cut -d' ' -f1)
	PPIDp=$(cat /proc/$tPID/stat 2>/dev/null | awk '{print $4}')

	if [ ! -z "$PPIDp" ]; then
		echo "PPIDp: $PPIDp" >/dev/console
	else
		echo "PPIDp: none" >/dev/console
	fi



	echo "PS-FSH: $FSH" >/dev/console



done #sh errors echo "DBGPSw $(ps w)" >/dev/kmsg









#WAITCNT=11
WAITCNT=15
while [ "$WAITCNT" -gt 0 ]; do
	echo "waiting for cnt: $WAITCNT" >/dev/kmsg
	WAITCNT=$((WAITCNT - 1))
	sleep 1
done















}


















##################################################################################
#!20220117 HMMM not available here MOVE to shutdown.sh
LANMAC=$(cat /sys/class/net/br-lan/address 2>/dev/null | cut -d : -f 1- | sed -e 's/://g')
if [ -z "$LANMAC" ]; then
	LANMAC=$(sed -n 's|^.*smsc95xx\.macaddr=\(\S\+\)\s.*|\1|p' /proc/cmdline | tr -dc A-F0-9 | tr A-Z a-z)	
fi
#if [ -z "$LANMAC"  ]; then $ecmd "lanmac [nope]" && exit 0; fi
if [ -f /etc/custom/$LANMAC.sh ]; then
	###$ecmd "/etc/custom/$LANMAC.sh reboot [ok]"
	###echo "/etc/custom/$LANMAC.sh reboot [ok]" > /dev/kmsg
	###sh /etc/custom/$LANMAC.sh reboot
	echo "/etc/custom/$LANMAC.sh shutdown [ok]" > /dev/kmsg
	sh /etc/custom/$LANMAC.sh shutdown
else
	: #$ecmd "/etc/custom/$LANMAC.sh startup [nope]"
fi

#################################################################################

















echo "calling sync" >/dev/kmsg
#sync #v "[sync and drop_caches]" #1?
sync 2>/dev/null 1>/dev/null; echo 3 > /proc/sys/vm/drop_caches 2>/dev/null 1>/dev/null










#v "Commencing upgrade. Closing all shell sessions."


#[root@dca632 /usbstick 46°]# fgrep -r trigger /lib/upgrade/
#/lib/upgrade/do_stage2:echo b 2>/dev/null >/proc/sysrq-trigger
#[root@dca632 /usbstick 46°]# cat /lib/upgrade/do_stage2 | grep -C10 trigger

#v "Rebooting system..."







#@@@think we need to umount smb@/usbstick/downloads before /usbstick
echo "calling umount -a" >/dev/kmsg
sleep 1











#echo "BORKOUT"
#echo "BORKOUT" >/dev/console
#exit 0





umount -a 1>/dev/null 2>/dev/null
sleep 5
#reboot -f
#sleep 5
#echo b 2>/dev/null >/proc/sysrq-trigger

echo "calling /bin/busybox ${bNAME} ${@}" >/dev/kmsg
sleep 1



#exec?
/bin/busybox ${bNAME} ${@}






#eKO "done -> test-exit0" ###NEVERREACHHERE
#sleep 2 #dbgslpforce
exit 0











#!/bin/sh



########################################################
#reboot /sbin/reboot > /bin/busybox
#halt /sbin/halt > /bin/busybox
#shutdown no x64 or rpi
########################################################
#0 */6 * * * /etc/init.d/rrdbackup backup
##############################




WRAPn="$0"

SHUTscr="/etc/custom/shutdown.sh"







########################################### as param1
#bNAME="${1}"; #shift; #echo "iam:$WRAPn calling: $bNAME ${@}"; #sleep 2



bNAME="$(basename $0)"

DEBUG=1
[ -n "$DEBUG" ] && RCSLEEP=1







eKO() {
	#[ -n "$DEBUG" ] && echo "$bNAME ${*}"
	[ -n "$DEBUG" ] && echo "consoleonly-$bNAME ${*}" > /dev/console
}










#@@@ case what we were called as...
case "$bNAME" in
    reboot)
        :
    ;;
    halt)
        :
    ;;

    *)
        eKO "OOOOOOOOOOOOOOOOOOOOOOOO: $0 ${*}"; sleep 7
    ;;
esac











#eKO "PAYLOADCMD(early): /bin/busybox ${bNAME} ${@}"; sleep ${RCSLEEP:-0}


if [ -f "$SHUTscr" ]; then #eKO "pre-shutdown: $SHUTscr"

    #$SHUTscr downearly



    #FIRSTBOOT IS A BETTERPLACE TO FIXUP THESE VARS in INI ONCE ONLY
    #############################################################################################
    #if [ -z "$LOGPERSIST" ]; then
    #    LOGPERSIST="/boot/plog"
    #    eKO "workaround LOGPERSIST:$LOGPERSIST wasz > /boot/plog"
    #elif [ "$LOGPERSIST" != '/boot/plog' ]; then

    #if [ ! -z "$LOGPERSIST" ] && [ "$LOGPERSIST" != '/boot/plog' ]; then
    #    eKO "workaround LOGPERSIST:$LOGPERSIST > /boot/plog"
    #    LOGPERSIST="/boot/plog"
    #fi #PSAVEDIR="/boot/psave"; fi; [ -n "$DEBUG"  ] && echq "PSAVEDIR=\"${PSAVEDIR}\""
    #############################################################################################


    eKO "RUNNING: $SHUTscr plog"
    $SHUTscr plog


    ########NOTE THIS IS DONE IN SHUTDOWN.SH NOW
    ##mkdir -p /restorefiles/plog
    ##cp -urf ${LOGPERSIST}/* /restorefiles/plog
    ##sync

    eKO "RUNNING: $SHUTscr shutdown"
	$SHUTscr shutdown #check it can find caller || not called from init.d debug print calling from here too...


else


    if [ "$(pwd)" = "/tmp/root" ]; then
        : #called from sysupgrade end
        eKO ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>> all done"
    else
        #notDEBUG@eKO
        eKO "pre-shutdown: $SHUTscr [missing]"; sleep ${RCSLEEP:-0}
    fi

fi
sleep ${RCSLEEP:-0}









#################################################### 20210399-fsckrootfs-corrupthere@rrdsave?inprogess...?
#v "Rebooting system..."

#echo "rebootwrapper... wait 3 secs (rrd finish?)" > /dev/console
echo "rebootwrapper... wait 3 secs (rrd finish?)" > /dev/kmsg
sleep 3

#echo "rebootwrapper... wait 5 secs (+umount -a)" > /dev/console
echo "rebootwrapper... wait 5 secs (+umount -a)" > /dev/kmsg
umount -a 2>/dev/null
sleep 5




#reboot -f
#sleep 5
#echo b 2>/dev/null >/proc/sysrq-trigger












#####3#probably veryfy -x early #eKO "PAYLOADCMD: /bin/busybox ${bNAME} ${@}" #sleep 7; sleep ${RCSLEEP:-0}
/bin/busybox ${bNAME} ${@}



###################################exit $? ??? #sleep ${RCSLEEP:-0}; sleep ${RCSLEEP:-0}; sleep ${RCSLEEP:-0}
###NEVERREACHHERE
eKO "done -> test-exit0"
sleep 2 #dbgslpforce
exit 0













#echo "$WRAPn ${*}"
#echo "$WRAPn 1: ${1}"
###############################
#WRAPn="/usr/sbin/reboot"
#WRAPn="/usr/sbin/$(basename $0)"
################################





################Usage: halt||reboot [-d DELAY] [-n] [-f]
#Halt the system
#	-d SEC	Delay interval
#	-n	Do not sync
#	-f	Force (don't go through init)
############################################/lib/upgrade/do_stage2:echo b 2>/dev/null >/proc/sysrq-trigger
###########root@pc-0800273dbd /# cat /lib/upgrade/do_stage2 | grep -C5 sysrq
#v "Rebooting system..."
#umount -a
#reboot -f
#sleep 5
#echo b 2>/dev/null >/proc/sysrq-trigger



##################
#    plog<shutdown) #init.d/persistdata?>LOGPERSIST? ######################################## init.d/persistdata boot|shutdown ~upgraded
                #LOGPERSIST (dirnotz)
#
#        [ -n "$DEBUG" ] && echSH "called from init.d persistdata: ${*}"
#        if [ -z "$LOGPERSIST" ]; then
#            echSH "logpersist [empty]"
#            [ -n "$DEBUG" ] && echSH "dbg sleep 3" && sleep 3
#            return 0
#        fi
#
#        mkdir -p "${LOGPERSIST}" || return 0
#        DSTAMP=$(date +%Y%m%d%H%M)
 #       LOGLINES=$(logread | wc -l)
#
#
#        echo "DBG dumping ${LOGPERSIST}/plogread-${DSTAMP}.log lines:$LOGLINES" > /dev/console && sleep 5


#        echSH "dumping ${LOGPERSIST}/plogread-${DSTAMP}.log lines:$LOGLINES" #sleep 2
#        logread > "${LOGPERSIST}"/plogread-${DSTAMP}.log
#
#        echSH "size: $(du -cs ${LOGPERSIST}/plogread-${DSTAMP}.log | head -n1)" #sleep 2
#        return 0
######################







    #echo "pwd"; pwd #pwd /tmp/root
    #we may be in tmpfs for sysupgrade :) detect and skipcheck(earlier->or do something else :)
    #? eKO "pre-shutdown: mount: $(mount)"; sleep ${RCSLEEP:-0}
    #zero eKO "pre-shutdown: ps-w: $(ps w)"; sleep ${RCSLEEP:-0}
    #echo "ls"; ls; sleep 5
    #echo "pwd"; pwd #pwd /tmp/root
    #noCMD> echo "df -h"; df -h
    #echo "sleep 55"; sleep 55






#reboot.sh:
###############################!/bin/sh
echo 1 > /proc/sys/kernel/sysrq
echo u > /proc/sysrq-trigger
sync
echo b > /proc/sysrq-trigger

#########################poweroff.sh:
############!/bin/sh
echo 1 > /proc/sys/kernel/sysrq
echo u > /proc/sysrq-trigger
sync
echo o > /proc/sysrq-trigger








#if ! mount | grep ' / ' | grep -q rw && [ -z "$ISTMPFS" ]; then


