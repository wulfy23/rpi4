return {
	name = "dns.pumplex.com",
	label = _("OSZX DNS (Pumplex)"),
	resolver_url = "https://dns.pumplex.com/dns-query",
	bootstrap_dns = "51.38.82.198,2001:41d0:801:2000::1b28",
	help_link = "https://dns.oszx.co/#mdoh",
	help_link_text = "OSZX.co"
}
