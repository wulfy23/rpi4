#!/bin/sh
###############################################
ecmd="echo"
i=$(basename $0)
if [ -x /etc/custom/custfunc.sh ]; then
	. /etc/custom/custfunc.sh
	ecmd="echm ${i} "
fi


#NOTE: THIS SCRIPT IS LEGACY AN NOT REALLY USED?
#$ecmd "######################################################"; #sleep 1






if [ -f /root/.backup ]; then

	#############################################
	if [ -d /root/backup/jobs ]; then


	#############################################
	$ecmd " ################### backup init ###"
	#############################################
	###opkg list-installed | cut -f 1 -d ' ' > /etc/config/packages.list
	###and use this to reinstall your packages after sysupgrade
	###opkg install $(cat /etc/config/packages.list)


	jobnum=`ls -l /root/backup/jobs/ | grep -v '^d' | wc -l`
	$ecmd "Found `ls -l /root/backup/jobs/ | grep -v '^d' | wc -l` backup jobs"
	if [ $jobnum -gt 0 ]; then

			for z in /root/backup/jobs/*; do

				if [ ! -d ${z} ]; then

					$ecmd "> Running job: ${z}"
					sleep 2
					sh $z
					#sleep 3
				fi

			done

		else
			#############################################
			$ecmd "> folder /root/backup/jobs not configured"
			#############################################
		fi
	fi
else
	#############################################
	$ecmd "> /root/.backup no present..... backups disabled"
	#############################################
fi




exit 0
#$ecmd "################################## end rc.custom ###"


