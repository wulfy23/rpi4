<?php

session_start();

function dumpredirect($log_msg)
{

?>

<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
<meta http-equiv="refresh" content="0; URL=/dl" />
</head>
<body style="background-color: white">
<a style="color: black; font-family: arial, helvetica, sans-serif;" href="/dl">dlreturn</a>
</body>
</html>



<?php

}

















function dumpheader($log_msg)
{

?>

<html>
<head>
<title>youtube-dl</title>
<style>
body{
	background-color:#708890;
	font-family:Arial;
	color:white;
}
.box{
	border: 1px solid;
	width:70%;
	margin:auto;
}
</style>
</head>
<body>
<center>





<h1>processing... </h1>

<div class="box">



<?php

}








// <?php




	// [root@dca632 /www/dl 45°]# cat /etc/php.ini | grep time
	// 240 max_execution_time = 30	; Maximum execution time of each script, in seconds






$dllog = "/tmp/dllog.txt";
$dlurl = "http://10.2.3.1/downloads";
$dlscript = '/bin/dl.sh';













if (file_exists($dlscript)) {


    // echo "The file $dlscript exists";






function wh_log($log_msg)
{
    $log_filename = "log";
    if (!file_exists($log_filename)) 
    {
        // create directory/folder uploads.
        mkdir($log_filename, 0777, true);
    }
    $log_file_data = $log_filename.'/log_' . date('d-M-Y') . '.log';
    // if you don't add `FILE_APPEND`, the file will be erased each time you add a log
    file_put_contents($log_file_data, $log_msg . "\n", FILE_APPEND);
    
    
    
    // shell_exec('echo ' . "$log_msg" . "\n" >/dev/console");
    // shell_exec("echo " . "$log_msg" . "\n" ">/dev/console");
    shell_exec("echo " . "$log_msg" . ">/dev/console");
}
// call to function
//wh_log("this is my log message");















// $mvdir = "/usbstick/downloads/audio";




$username = $_POST['username'];
wh_log("username:$username");



//$url = $_POST['url'];
//wh_log("url:$url");








// provideseperateurlboxs?
// $dltype = $_POST['dltype'];




if (isset($_POST['url_audio'])) {
	if (!empty($_POST['url_audio'])) {
	$url = $_POST['url_audio'];
	$dltype = 'audio-mp3';
	}
}


if (isset($_POST['url_video'])) {
	if (!empty($_POST['url_video'])) {
	$url = $_POST['url_video'];
	$dltype = 'video';
	}
}








if (isset($_POST['url_audio_clip'])) {
	if (!empty($_POST['url_audio_clip'])) {
	$url = $_POST['url_audio_clip'];
	$dltype = 'audio-video';
	}
}



if (isset($_POST['url_audio_both'])) {
	if (!empty($_POST['url_audio_both'])) {
	$url = $_POST['url_audio_both'];
	$dltype = 'audio-both';
	}
}













wh_log("url:$url");








wh_log("dltype:$dltype");
// $mvdir = "/usbstick/downloads/audio/$username";












$thedate = shell_exec("date +%S 2>/dev/null");
wh_log("thedate:$thedate");












// $username = "word";
// $url = "https://www.youtube.com/watch?v=gOMhN-hfMtY";
// $dltype = "audio-both";








// TOP session_start();


$_SESSION['username'] = $username;












switch ($dltype) {
    case "audio-both":
	// echo exec("/bin/dl.sh -U $username -Y -A2 -url $url 2>&1", $output);
	wh_log("BOTH");
	// exec("/bin/dl.sh -U $username -Y -A2 -url $url 2>&1", $output);
	// original echo exec("/bin/dl.sh -U $username -Y -A2 -url $url 2>&1", $output);
	//NOPE echo exec("/bin/dl.sh -U $username -Y -A2 -url $url 2>&1 1>/dev/null", $output);
	// echo exec("/bin/dl.sh -U $username -Y -A2 -url $url 2>&1 1>/dev/null", $output);
	#echo exec("/bin/dl.sh -W -U $username -Y -A2 -url $url 2>&1", $output);
	###############echo exec("/bin/dl.sh -B -W -U $username -Y -A2 -url $url 2>&1", $output);
	#echo exec("(/bin/dl.sh -B -W -U $username -Y -A2 -url $url 2>&1)&", $output);
	#print_r($output);
	
	
	#shell_exec('service named reload >/dev/null 2>/dev/null &');
	shell_exec("/bin/dl.sh -B -W -U $username -Y -A2 -url $url >/dev/null 2>/dev/null &");
	
	
	// ARRAY echo $output;
        break;
    case "audio-mp3":
	wh_log("MP3");
	#echo exec("/bin/dl.sh -W -U $username -Y -A -url $url 2>&1", $output);
	##############echo exec("/bin/dl.sh -B -W -U $username -Y -A -url $url 2>&1", $output);
	
	#echo exec("(/bin/dl.sh -B -W -U $username -Y -A -url $url 2>&1)&", $output);
	#print_r($output);
	
	
	shell_exec("/bin/dl.sh -B -W -U $username -Y -A -url $url >/dev/null 2>/dev/null &");
        break;
    case "audio-video":
	wh_log("AVID");
	#echo exec("/bin/dl.sh -W -U $username -Y -AV -url $url 2>&1", $output);
	#######################echo exec("/bin/dl.sh -B -W -U $username -Y -AV -url $url 2>&1", $output);
	#echo exec("(/bin/dl.sh -B -W -U $username -Y -AV -url $url 2>&1)&", $output);
	#print_r($output);
	
	shell_exec("/bin/dl.sh -B -W -U $username -Y -AV -url $url >/dev/null 2>/dev/null &");
        break;
    case "video":
	wh_log("VID");
	#echo exec("/bin/dl.sh -W -U $username -Y -url $url 2>&1", $output);
	####################echo exec("/bin/dl.sh -B -W -U $username -Y -url $url 2>&1", $output);
	#echo exec("(/bin/dl.sh -B -W -U $username -Y -url $url 2>&1)&", $output);
	#print_r($output);
	
	
	shell_exec("/bin/dl.sh -B -W -U $username -Y -url $url >/dev/null 2>/dev/null &");
        break;
}
















function dumpfooter($log_msg)
{





echo "Operation completed successfully";
echo "<a href=" . '"' . $dlurl . '"' . ">$dlurl</a>";

#$dllog = "/tmp/dllog.txt";
#DOESNOTEXIST echo exec("tail -n10 $dllog 2>&1", $output);
echo exec("tail -n10 $dllog 2>/dev/null", $output);

print_r($output);







// echo exec("/bin/dl.sh -U $username -Y -A2 -url $url 2>&1", $output);
// echo $output;
// ### echo exec("youtube-dl --extract-audio --audio-format mp3 $url 2>&1", $output);
// ### print_r($output);




?>











</div>
<p>

</p>
<p><img src="dl.png"></p>
<h3>Please click below to download another song.</h3>











<?php

//echo "File saved as:";
//echo exec("ls *.mp3 2>&1", $output1);
//echo "$output1";

// Move new .mp3 file to desired location

//echo exec("mv *.mp3 $mvdir/ 2>&1", $output2);
//echo "Moving files...";
// echo "$output2";









?>


<p><a href="index.php">⇐ Return</a></p>
</body>
</html>



<?php


}
//ENDDUMPFOOTERWRAPALLBASEOUTPUT













dumpredirect($log_msg);












} else {
    echo "The file $dlscript does not exist";
}



?>



















