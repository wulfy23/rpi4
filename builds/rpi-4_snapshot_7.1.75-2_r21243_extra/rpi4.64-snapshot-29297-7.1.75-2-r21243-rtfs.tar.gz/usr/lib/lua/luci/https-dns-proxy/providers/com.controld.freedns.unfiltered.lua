return {
	name = "ControlD-Unfiltered",
	label = _("ControlD (Unfiltered)"),
	resolver_url = "https://freedns.controld.com/p0",
	bootstrap_dns = "76.76.2.0,2606:1a40::0",
	help_link = "https://kb.controld.com/tutorials",
	help_link_text = "ControlD"
}
